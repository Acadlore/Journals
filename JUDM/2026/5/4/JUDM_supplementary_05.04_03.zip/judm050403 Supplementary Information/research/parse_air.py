import re,pathlib,csv,json
rows=[];audit=[]
for y in range(2019,2026):
    pages=pathlib.Path(f'research/PRD_{y}.txt').read_text().split('\f')
    for page,p in enumerate(pages):
        p=p.replace('Tung Chung (Hong','Tung Chung').replace('Kong)', '(Hong Kong)')
        p=re.sub(r'\(Hong\s*\n\s*Kong\)', '(Hong Kong)', p)
        first=p[:350].lower()
        if 'monthly and annual' not in first or 'station' not in p[:650].lower(): continue
        pol=next((x for x in ['PM2.5','PM10','Sulphur Dioxide','Nitrogen Dioxide','Ozone','Carbon Monoxide'] if x.lower() in first),None)
        if not pol: continue
        pol={'Sulphur Dioxide':'SO2','Nitrogen Dioxide':'NO2','Ozone':'O3','Carbon Monoxide':'CO'}.get(pol,pol)
        name='';pending=None;count=0
        for line in p.splitlines():
            if line.strip().startswith('Note'): break
            m=re.search(r'(?<![A-Za-z0-9])(?:\d+(?:\.\d+)?\*{0,2}|--?)\s+(?:\d+(?:\.\d+)?\*{0,2}|--?)\s+(?:\d+(?:\.\d+)?\*{0,2}|-)',line)
            if m:
                vals=[v for v in line[m.start():].split() if re.fullmatch(r'(?:\d+(?:\.\d+)?\*{0,2}|--?)',v)]
                if len(vals)==13:
                    prefix=line[:m.start()].strip()
                    if prefix: name=re.sub(r'\([^)]*\)','',prefix).strip()
                    pending=(name,vals)
            cm=re.search(r'\((Guangzhou|Shenzhen|Foshan|Zhuhai|Jiangmen|Zhaoqing|Huizhou|Zhongshan|Dongguan|Hong Kong|Macao)\)',line)
            if cm and pending:
                station,v=pending
                canonical=['Luhu','Modiesha','Wanqingsha','Tianhu','Zhudong','Liyuan','Jinjuzui','Huijingcheng','Tangjia','Donghu','Duanfen','Huaguoshan','Chengzhong','Xiapu','Xijiao','Jinguowan','Zimaling','Nanchengyuanling','Tap Mun','Tsuen Wan','Yuen Long','Tung Chung','Taipa Grande']
                expected=['Guangzhou']*5+['Shenzhen']+['Foshan']*2+['Zhuhai']+['Jiangmen']*3+['Zhaoqing']+['Huizhou']*3+['Zhongshan','Dongguan']+['Hong Kong']*4+['Macao']
                assert cm[1]==expected[count],(y,pol,count,cm[1])
                station=canonical[count]
                if y>=2019: station={'Wanqingsha':'Nansha-HKUST','Liyuan':'Tongxinling'}.get(station,station)
                if y>=2021 and station=='Modiesha': station='Nanshadawen'
                if y>=2023 and station=='Xijiao': station='Shixia'
                for mo,x in enumerate(v,1):
                    rows.append(dict(year=y,pollutant=pol,station=station,city=cm[1],month=mo if mo<13 else 0,value=None if x in ['-','--'] else float(x.strip('*')),flag=len(x)-len(x.rstrip('*')),source_page=page+1))
                pending=None;count+=1
            s=line.strip()
            if re.fullmatch(r'[A-Za-z][A-Za-z\s-]*',s) and s not in ['Average','Annual','Monitoring Station','Station']: name=s
        audit.append((y,pol,page+1,count))
with open('research/air_observations.csv','w') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print('rows',len(rows),'tables',len(audit))
print(audit)
pathlib.Path('research/extraction_audit.json').write_text(json.dumps(audit))
