import pandas as pd, numpy as np, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'processed_inputs/nsrdb_phoenix_2023_5min.csv'
df=pd.read_csv(p,skiprows=2)
lat=33.44; lon=-112.07; tz=-7; tilt=np.deg2rad(20); surfaz=np.deg2rad(180); alb=.2
# timestamps local standard time
idx=pd.to_datetime(dict(year=df.Year,month=df.Month,day=df.Day,hour=df.Hour,minute=df.Minute))
# NOAA fractional year / declination / eqtime (local standard)
doy=idx.dt.dayofyear.to_numpy(); hour=idx.dt.hour.to_numpy()+idx.dt.minute.to_numpy()/60
gamma=2*np.pi/365*(doy-1+(hour-12)/24)
eqtime=229.18*(0.000075+0.001868*np.cos(gamma)-0.032077*np.sin(gamma)-0.014615*np.cos(2*gamma)-0.040849*np.sin(2*gamma))
decl=(0.006918-0.399912*np.cos(gamma)+0.070257*np.sin(gamma)-0.006758*np.cos(2*gamma)+0.000907*np.sin(2*gamma)-0.002697*np.cos(3*gamma)+0.00148*np.sin(3*gamma))
time_offset=eqtime+4*lon-60*tz
tst=hour*60+time_offset
ha=np.deg2rad(tst/4-180)
latr=np.deg2rad(lat)
cosz=np.sin(latr)*np.sin(decl)+np.cos(latr)*np.cos(decl)*np.cos(ha)
cosz=np.clip(cosz,-1,1); zen=np.arccos(cosz)
# solar azimuth degrees clockwise from north using atan2
# formula: atan2(sin ha, cos ha sin lat - tan decl cos lat) + 180 deg
az=np.arctan2(np.sin(ha), np.cos(ha)*np.sin(latr)-np.tan(decl)*np.cos(latr)) + np.pi
# surface normal z-up components, sun vector; cos AOI formula
cosaoi=np.cos(zen)*np.cos(tilt)+np.sin(zen)*np.sin(tilt)*np.cos(az-surfaz)
cosaoi=np.maximum(cosaoi,0)
GHI=df.GHI.to_numpy(float); DNI=df.DNI.to_numpy(float); DHI=df.DHI.to_numpy(float); Tamb=df.Temperature.to_numpy(float)
poa=DNI*cosaoi + DHI*(1+np.cos(tilt))/2 + GHI*alb*(1-np.cos(tilt))/2
poa=np.maximum(poa,0)
NOCT=45; gammap=-.0035; dcac=1.3; inv=.98; rated=230
Tcell=Tamb+(NOCT-20)/800*poa
# candidate A: DC nameplate = dcac*ACrated, module output, inverter eff, clip ACrated
Pdc=rated*dcac*(poa/1000)*(1+gammap*(Tcell-25))
Pac=np.clip(Pdc*inv,0,rated)
print('zen MAE',np.mean(np.abs(np.rad2deg(zen)-df['Solar Zenith Angle'].to_numpy(float))), 'rmse',np.sqrt(np.mean((np.rad2deg(zen)-df['Solar Zenith Angle'].to_numpy(float))**2)))
print('energy GWh',Pac.sum()*5/60/1000,'CF',Pac.mean()/rated,'max',Pac.max())
# 15m means
out=pd.DataFrame({'timestamp':idx,'pv_ac_mw':Pac,'ambient_C':Tamb,'poa':poa,'zen_calc':np.rad2deg(zen)})
out15=out.set_index('timestamp').resample('15min').mean().reset_index()
print('15 energy',out15.pv_ac_mw.sum()*.25/1000,'n',len(out15))
(ROOT/'reproduced_outputs').mkdir(exist_ok=True)
out.to_csv(ROOT/'reproduced_outputs/recon_pv5.csv',index=False); out15.to_csv(ROOT/'reproduced_outputs/recon_pv15.csv',index=False)
