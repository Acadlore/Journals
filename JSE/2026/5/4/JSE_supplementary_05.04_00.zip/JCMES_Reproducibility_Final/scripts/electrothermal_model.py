from pathlib import Path
import numpy as np, pandas as pd, math, json
from scipy.optimize import linprog, brentq
from scipy.sparse import lil_matrix
ROOT=Path(__file__).resolve().parents[1]; B=ROOT/'battery_model'
ocvdf=pd.read_csv(B/'ocv_surface_V.csv',index_col=0); r0df=pd.read_csv(B/'r0_surface_ohm.csv',index_col=0); capdf=pd.read_csv(B/'capacity_vs_temperature.csv'); rc0=pd.read_csv(B/'rc_parameters_rest_identification.csv')
Tg=np.array(ocvdf.index,float); zg=np.array(ocvdf.columns,float); O=ocvdf.to_numpy(float); R0M=r0df.to_numpy(float)
capT=capdf.temperature_C.to_numpy(float); capQ=capdf.capacity_Ah.to_numpy(float); rcT=rc0['T'].to_numpy(float); rcR=rc0.R1_ohm.to_numpy(float)
therm=json.load(open(B/'thermal_parameters.json')); RTH0=therm['Rth_K_per_W']; CTH0=therm['Cth_J_per_K']; HEAT0=therm['heat_scale']
VN=3.3; QN_NOM=2.5; QREF25=float(np.interp(25.0,capT,capQ)); ETAPCS=.98; VMAX=3.6; VMIN=2.0; ICH=10.; IDIS=50.; TMAX=55.; SMIN=.1; SMAX=.9; S0=.5; ERATE=230.

def _ocv25_value(z):
    tt=25.0; j=np.searchsorted(Tg,tt)
    if j<=0: return float(np.interp(z,zg,O[0]))
    if j>=len(Tg): return float(np.interp(z,zg,O[-1]))
    w=(tt-Tg[j-1])/(Tg[j]-Tg[j-1])
    return float((1-w)*np.interp(z,zg,O[j-1])+w*np.interp(z,zg,O[j]))

def _ocv25_integral(zlo=SMIN,zhi=SMAX):
    """Integral of identified 25 C OCV over SOC, including exact window edges."""
    zpts=np.unique(np.r_[float(zlo),zg[(zg>zlo)&(zg<zhi)],float(zhi)])
    u=np.array([_ocv25_value(z) for z in zpts],float)
    return float(np.trapezoid(u,zpts))

OCV25_WINDOW_INTEGRAL_V=_ocv25_integral()
OCV25_WINDOW_ENERGY_WH_PER_CELL=QREF25*OCV25_WINDOW_INTEGRAL_V

# Energy-basis normalization: the physical cell population is
# chosen so that the identified 25 C OCV-integrated energy over the actual
# dispatch SOC window (0.10-0.90) is exactly equal to E*(0.90-0.10).
def equivalent_cell_count(E_MWh):
    usable_pack_Wh=E_MWh*1e6*(SMAX-SMIN)
    return usable_pack_Wh/OCV25_WINDOW_ENERGY_WH_PER_CELL


def ss(M,z,T):
    z=np.clip(float(z),0,1); tt=np.clip(float(T),Tg[0],Tg[-1]); j=np.searchsorted(Tg,tt)
    if j<=0:return float(np.interp(z,zg,M[0]))
    if j>=len(Tg):return float(np.interp(z,zg,M[-1]))
    w=(tt-Tg[j-1])/(Tg[j]-Tg[j-1]); return float((1-w)*np.interp(z,zg,M[j-1])+w*np.interp(z,zg,M[j]))
def cap(T): return float(np.interp(np.clip(T,capT[0],capT[-1]),capT,capQ))
def r1(T): return float(np.interp(np.clip(T,rcT[0],rcT[-1]),rcT,rcR))

def props(z,T,flags):
    To=T if flags.get('OCV',False) else 25.0
    Tr=T if flags.get('R',False) else 25.0
    Tq=T if flags.get('Q',False) else 25.0
    return ss(O,z,To), ss(R0M,z,Tr)+r1(Tr), cap(Tq)

def solve_lp(pv,dt,pcap,pmax,E,ach,adis,chl,dsl,s0=S0):
    n=len(pv);sur=np.maximum(pv-pcap,0);head=np.maximum(pcap-pv,0);N=3*n+1;c=np.zeros(N);eps=1e-7;c[:n]=(-1.0+eps)*dt;c[n:2*n]=eps*dt
    bd=[(0,min(pmax,sur[k],chl[k])) for k in range(n)]+[(0,min(pmax,head[k],dsl[k])) for k in range(n)]+[(SMIN,SMAX)]*(n+1)
    A=lil_matrix((n+2,N));b=np.zeros(n+2);A[0,2*n]=1;b[0]=s0
    for k in range(n):
        A[1+k,2*n+k+1]=1;A[1+k,2*n+k]=-1;A[1+k,k]=-ach[k];A[1+k,n+k]=adis[k]
    A[-1,3*n]=1;b[-1]=s0
    res=linprog(c,A_eq=A.tocsr(),b_eq=b,bounds=bd,method='highs')
    if not res.success: raise RuntimeError(res.message)
    x=res.x; return x[:n],x[n:2*n],x[2*n:]

def replay(pv,ch,dis,amb,dt,pmax,E,config=None,rth=RTH0,cth=CTH0,kappa=HEAT0,s0=S0):
    # Configuration controls temperature dependence in state conversion and feasibility, self-heating, and the thermal dispatch cutoff.
    if config is None: config={'dyn':{'Q':1,'R':1,'OCV':1},'feas':{'Q':1,'R':1,'OCV':1},'selfheat':True,'thermal_cutoff':True}
    dyn=config['dyn']; feas=config['feas']; selfheat=bool(config.get('selfheat',True)); cutoff=bool(config.get('thermal_cutoff',True))
    n=len(pv);NC=equivalent_cell_count(E);z=s0; capTstate=config.get('thermal_state_cap_C',None); T=float(amb[0]); T=min(T,float(capTstate)) if capTstate is not None else T; aa=math.exp(-(dt*3600)/(rth*cth))
    zs=np.empty(n+1);zs[0]=z; Ts=np.empty(n); Is=np.empty(n); Vs=np.empty(n); chf=np.empty(n);disf=np.empty(n);chl=np.empty(n);dsl=np.empty(n);ach=np.empty(n);adis=np.empty(n);Rtot=np.empty(n);ocvv=np.empty(n);Qv=np.empty(n); domain=np.zeros(n,bool)
    for k in range(n):
        Tp=T; domain[k]=(Tp<Tg[0]) or (Tp>Tg[-1]); U,R,Q=props(z,Tp,dyn); Uf,Rf,Qf=props(z,Tp,feas)
        ich=min(ICH,max(0,(VMAX-Uf)/max(Rf,1e-12)),max(0,(SMAX-z)*Qf/dt)); jd=min(IDIS,max(0,(Uf-VMIN)/max(Rf,1e-12)),max(0,(z-SMIN)*Qf/dt))
        if cutoff and Tp>=TMAX: ich=jd=0
        chl[k]=min(pmax,ich*(Uf+ich*Rf)*NC/1e6/ETAPCS); dsl[k]=min(pmax,jd*max(Uf-jd*Rf,0)*NC/1e6*ETAPCS)
        pc=min(max(ch[k],0),chl[k]); pd=min(max(dis[k],0),dsl[k]);chf[k]=pc;disf[k]=pd
        if pc>1e-10:
            pt=pc*ETAPCS*1e6/NC;I=(-U+math.sqrt(max(0,U*U+4*R*pt)))/(2*R);V=U+I*R
        elif pd>1e-10:
            pt=pd/ETAPCS*1e6/NC;disc=max(0,U*U-4*R*pt);j=(U-math.sqrt(disc))/(2*R);I=-j;V=U-j*R
        else:I=0.;V=U
        znew=float(np.clip(z+I*dt/Q,SMIN,SMAX))
        if pc>1e-8: ach[k]=max((znew-z)/pc,1e-12)
        else: ach[k]=ETAPCS*1e6/NC/max(U,1e-6)*dt/Q
        if pd>1e-8: adis[k]=max((z-znew)/pd,1e-12)
        else: adis[k]=1e6/(ETAPCS*NC*max(U,1e-6))*dt/Q
        q=(kappa if selfheat else 0.0)*I*I*R
        T=aa*T+(1-aa)*(amb[k]+rth*q)
        if capTstate is not None: T=min(T,float(capTstate))
        z=znew;zs[k+1]=z;Ts[k]=T;Is[k]=I;Vs[k]=V;Rtot[k]=R;ocvv[k]=U;Qv[k]=Q
    return {'soc':zs,'T':Ts,'I':Is,'V':Vs,'R':Rtot,'OCV':ocvv,'QAh':Qv,'ch':chf,'dis':disf,'chlim':chl,'dislim':dsl,'ach':ach,'adis':adis,'domain':domain}

def terminal_repair(pv,ch,dis,amb,dt,pcap,pmax,E,config,rth,cth,kappa,tol=2e-7):
    # Every root-finding trial must preserve the plant-side POI
    # constraints as well as the physical battery constraints. Scaling discharge
    # or charge cannot create export above pcap or charge beyond instantaneous PV surplus.
    surplus=np.maximum(np.asarray(pv,float)-pcap,0.0)
    headroom=np.maximum(pcap-np.asarray(pv,float),0.0)
    def F(c,d):
        c_req=np.minimum(np.maximum(np.asarray(c,float),0.0),np.minimum(pmax,surplus))
        d_req=np.minimum(np.maximum(np.asarray(d,float),0.0),np.minimum(pmax,headroom))
        return replay(pv,c_req,d_req,amb,dt,pmax,E,config,rth,cth,kappa)
    rr=F(ch,dis);e=rr['soc'][-1]-S0
    if abs(e)<=tol:return rr['ch'].copy(),rr['dis'].copy(),rr,False
    def f(s):return F(ch,dis*s)['soc'][-1]-S0
    if np.any(dis>1e-9):
        if e>0:
            lo,hi=1.,1.05;fhi=f(hi)
            while fhi>0 and hi<4.:hi*=1.5;fhi=f(hi)
            if fhi<=0:
                s=brentq(f,lo,hi,xtol=1e-11);rr2=F(ch,dis*s)
                if abs(rr2['soc'][-1]-S0)<=1e-6:return rr2['ch'].copy(),rr2['dis'].copy(),rr2,True
        else:
            flo=f(0.)
            if flo>=0:
                s=brentq(f,0.,1.,xtol=1e-11);rr2=F(ch,dis*s)
                if abs(rr2['soc'][-1]-S0)<=1e-6:return rr2['ch'].copy(),rr2['dis'].copy(),rr2,True
    def g(s):return F(ch*s,dis)['soc'][-1]-S0
    if np.any(ch>1e-9):
        if e<0:
            lo,hi=1.,1.05;ghi=g(hi)
            while ghi<0 and hi<4.:hi*=1.5;ghi=g(hi)
            if ghi>=0:
                s=brentq(g,lo,hi,xtol=1e-11);rr2=F(ch*s,dis);return rr2['ch'].copy(),rr2['dis'].copy(),rr2,True
        else:
            glo=g(0.)
            if glo<=0:
                s=brentq(g,0.,1.,xtol=1e-11);rr2=F(ch*s,dis);return rr2['ch'].copy(),rr2['dis'].copy(),rr2,True
    return rr['ch'].copy(),rr['dis'].copy(),rr,False

def solve_day(pv,amb,dt,alpha=.85,pmax=30.,E=140.,config=None,rth=RTH0,cth=CTH0,kappa=HEAT0,maxiter=10,damp=.5,term_tol=5e-4,min_replays=5):
    """Final revised daily solver used after Editor Note #8.

    B1 is the fixed-efficiency LP. B2 is the terminal-corrected nonlinear
    replay of B1. B3 uses sequential linearization. Candidate selection
    avoids initialization bias by comparing physically replayed curtailment
    among numerically admissible replay states (zero clipping and terminal
    error below ``term_tol``), rather than ranking terminal error ahead of
    curtailment. At least ``min_replays`` replay states and one replay after
    first satisfying the convergence criterion are evaluated, subject to
    ``maxiter``.
    """
    if config is None:
        config={'dyn':{'Q':1,'R':1,'OCV':1},'feas':{'Q':1,'R':1,'OCV':1},'selfheat':True,'thermal_cutoff':True}
    pcap=alpha*ERATE; n=len(pv); ETA=.98
    ach0=np.full(n,ETA*dt/E); adis0=np.full(n,dt/(ETA*E)); lims=np.full(n,pmax)
    ch1,dis1,soc1=solve_lp(pv,dt,pcap,pmax,E,ach0,adis0,lims,lims)

    rr2raw=replay(pv,ch1,dis1,amb,dt,pmax,E,config,rth,cth,kappa)
    ch2,dis2,rr2,repaired2=terminal_repair(pv,rr2raw['ch'],rr2raw['dis'],amb,dt,pcap,pmax,E,config,rth,cth,kappa)

    ch,dis=ch1.copy(),dis1.copy(); candidates=[]; firstconv=None; lp_failed=False
    for it in range(maxiter):
        rr=replay(pv,ch,dis,amb,dt,pmax,E,config,rth,cth,kappa)
        cur=float(np.maximum(pv-pcap-rr['ch'],0).sum()*dt)
        term=abs(rr['soc'][-1]-S0)
        clip=int((rr['ch']+1e-8<ch).sum()+(rr['dis']+1e-8<dis).sum())
        candidates.append({'it':it,'clip':clip,'term':term,'cur':cur,'ch':ch.copy(),'dis':dis.copy(),'rr':rr})
        if clip==0 and term<term_tol and it>=2 and firstconv is None:
            firstconv=it
        # At least min_replays states and one state after first convergence.
        if firstconv is not None and it>=max(min_replays-1,firstconv+1):
            break
        try:
            chn,disn,_=solve_lp(pv,dt,pcap,pmax,E,rr['ach'],rr['adis'],rr['chlim'],rr['dislim'])
        except RuntimeError:
            lp_failed=True; break
        ch=(1-damp)*rr['ch']+damp*chn
        dis=(1-damp)*rr['dis']+damp*disn

    eligible=[c for c in candidates if c['it']>=2 and c['clip']==0 and c['term']<term_tol]
    if eligible:
        best=min(eligible,key=lambda c:(c['cur'],c['term']))
    else:
        fallback=[c for c in candidates if c['it']>=2] or candidates
        best=min(fallback,key=lambda c:(c['clip']>0,c['term'],c['cur']))

    rr3pre=best['rr']
    ch3,dis3,rr3,repaired3=terminal_repair(pv,rr3pre['ch'],rr3pre['dis'],amb,dt,pcap,pmax,E,config,rth,cth,kappa)
    b0=np.maximum(pv-pcap,0)
    b1=np.maximum(pv-pcap-ch1,0)
    b2raw=np.maximum(pv-pcap-rr2raw['ch'],0)
    b2=np.maximum(pv-pcap-rr2['ch'],0)
    b3=np.maximum(pv-pcap-rr3['ch'],0)
    return {
        'b0':b0,'b1':b1,'b2raw':b2raw,'b2':b2,'b3':b3,
        'rr2raw':rr2raw,'rr2':rr2,'rr3':rr3,
        'b3_iter':best['it'],'b2_repaired':repaired2,'b3_repaired':repaired3,
        'n_replays':len(candidates),'first_conv_it0':firstconv,'lp_failed':lp_failed,
        'best_clip':best['clip'],'best_term':best['term']
    }

CONFIGS={
'fixed25': {'dyn':{'Q':0,'R':0,'OCV':0},'feas':{'Q':0,'R':0,'OCV':0},'selfheat':False,'thermal_cutoff':False},
'Q_only': {'dyn':{'Q':1,'R':0,'OCV':0},'feas':{'Q':0,'R':0,'OCV':0},'selfheat':False,'thermal_cutoff':False},
'R_only': {'dyn':{'Q':0,'R':1,'OCV':0},'feas':{'Q':0,'R':0,'OCV':0},'selfheat':False,'thermal_cutoff':False},
'OCV_only': {'dyn':{'Q':0,'R':0,'OCV':1},'feas':{'Q':0,'R':0,'OCV':0},'selfheat':False,'thermal_cutoff':False},
'feasibility_only': {'dyn':{'Q':0,'R':0,'OCV':0},'feas':{'Q':1,'R':1,'OCV':1},'selfheat':False,'thermal_cutoff':True},
'all_pathA': {'dyn':{'Q':1,'R':1,'OCV':1},'feas':{'Q':1,'R':1,'OCV':1},'selfheat':False,'thermal_cutoff':True},
'all_full': {'dyn':{'Q':1,'R':1,'OCV':1},'feas':{'Q':1,'R':1,'OCV':1},'selfheat':True,'thermal_cutoff':True},
}
