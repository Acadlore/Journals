from pathlib import Path
import pandas as pd,numpy as np,json
from scipy.stats import theilslopes,spearmanr,binomtest
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path('output');O.mkdir(exist_ok=True)
P=['PM10','PM2.5','NO2','SO2','O3']
x=pd.read_csv('research/air_observations.csv');x=x[x.pollutant.isin(P)].copy()
x.loc[(x.year==2023)&(x.city=='Huizhou')&(x.station.isna()|x.station.eq('^')),'station']='Shixia'
x['station_id']=x.station.replace({'Nansha-HKUST':'Wanqingsha','Tongxinling':'Liyuan'})
assert not x.duplicated(['year','pollutant','station_id','month']).any()
x=x[x.year>=2019].copy()
x.to_csv(O/'station_observations_2019_2025.csv',index=False)
x=x[x.year>=2019].copy()
a=x[x.month==0].copy();a.to_csv(O/'station_annual_2019_2025.csv',index=False)
c=a.groupby(['city','year','pollutant'],as_index=False).value.mean()
c.to_csv(O/'city_station_means_2019_2025.csv',index=False)
# Reference-only annual figures are removed for all inferential sensitivity checks.
strict=a[(a.flag==0)&a.value.notna()]
excluded=['Modiesha','Nanshadawen','Xijiao','Shixia','Zhudong','Duanfen','Tap Mun']
fixed=a[~a.station_id.isin(excluded)].copy()
assert fixed.station_id.nunique()==18
fixed.to_csv(O/'fixed_station_annual_2019_2025.csv',index=False)
stats=[]
for p in P:
 for label,df in [('all',a),('fixed18',fixed),('unflagged',strict)]:
  z=df[df.pollutant==p].groupby('year').value.mean()
  slope=theilslopes(z.values,z.index.values)
  stats.append(dict(pollutant=p,sample=label,mean2019=z[2019],mean2025=z[2025],pct_change=100*(z[2025]/z[2019]-1),sen_slope=slope.slope))
pd.DataFrame(stats).to_csv(O/'trend_sensitivity.csv',index=False)
# Simultaneous city changes; exact sign tests are exploratory because cities share an airshed.
summary=[]
for p in P:
 z=c[c.pollutant==p].pivot(index='city',columns='year',values='value')
 diff=z[2025]-z[2019]
 counts=((diff<0).sum(),(diff>0).sum(),(diff==0).sum())
 s0=z[2019].std(ddof=0);s1=z[2025].std(ddof=0)
 summary.append(dict(pollutant=p,city_mean2019=z[2019].mean(),city_mean2025=z[2025].mean(),decrease=int(counts[0]),increase=int(counts[1]),tie=int(counts[2]),sd2019=s0,sd2025=s1,cv2019=s0/z[2019].mean(),cv2025=s1/z[2025].mean(),rank_rho=spearmanr(z[2019],z[2025]).statistic))
pd.DataFrame(summary).to_csv(O/'city_dispersion_summary.csv',index=False)
end=c[c.year.isin([2019,2024,2025])].pivot(index='city',columns=['pollutant','year'],values='value')
end.to_csv(O/'city_endpoint_comparison.csv')
# 2024 GDP data transcribed from Guangzhou Statistical Yearbook 2025 Appendix 5.
E=pd.DataFrame([
['Guangzhou',164171,31032.50,2.1],['Shenzhen',205714,36801.87,5.8],['Zhuhai',178712,4479.06,3.5],['Foshan',138363,13361.90,1.3],['Huizhou',100677,6136.39,4.2],['Dongguan',116661,12282.15,4.6],['Zhongshan',92558,4143.25,3.7],['Jiangmen',87303,4210.18,3.4],['Zhaoqing',70603,2917.85,2.2],['Hong Kong',385380,28996.48,2.5],['Macao',520723,3572.12,8.8]],columns=['city','gdp_pc_cny2024','gdp_100million_cny2024','real_gdp_growth_pct2024'])
E=E.merge(c[c.year==2024].pivot(index='city',columns='pollutant',values='value'),on='city')
E.to_csv(O/'economic_context_2024.csv',index=False)
econ=[]
for p in P:
 r=spearmanr(E.gdp_pc_cny2024,E[p]).statistic
 mainland=E[~E.city.isin(['Hong Kong','Macao'])]
 loo=[spearmanr(E.drop(i).gdp_pc_cny2024,E.drop(i)[p]).statistic for i in E.index]
 econ.append(dict(pollutant=p,rho11=r,rho9=spearmanr(mainland.gdp_pc_cny2024,mainland[p]).statistic,loo_min=min(loo),loo_max=max(loo)))
pd.DataFrame(econ).to_csv(O/'economic_rank_associations.csv',index=False)
# Seasonal regional coherence using monthly first differences after removing station-specific month effects.
monthly=x[(x.month>0)&x.value.notna()&(x.flag==0)]
mo=monthly.groupby(['city','year','month','pollutant'],as_index=False).value.mean()
cor=[]
for p in P:
 t=mo[mo.pollutant==p].copy();t['time']=12*t.year+t.month
 t['anomaly']=t.value-t.groupby(['city','month']).value.transform('mean')
 q=t.pivot(index='time',columns='city',values='anomaly').diff()
 mat=q.corr(method='spearman',min_periods=80)
 v=mat.values[np.triu_indices(11,1)]
 cor.append(dict(pollutant=p,eligible_pairs=int(np.isfinite(v).sum()),median_rho=float(np.nanmedian(v)),min_rho=float(np.nanmin(v)),max_rho=float(np.nanmax(v))))
 mat.to_csv(O/f'monthly_comovement_{p}.csv')
pd.DataFrame(cor).to_csv(O/'monthly_comovement_summary.csv',index=False)
plt.rcParams.update({'font.family':'Liberation Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':350})
colors={'PM10':'#185C85','PM2.5':'#31979A','NO2':'#B16B32','SO2':'#858A91','O3':'#973C64'}
fig,ax=plt.subplots(figsize=(7.1,3.8))
for p in P:
 s=fixed[fixed.pollutant==p].groupby('year').value.mean();ax.plot(s.index,100*s/s.iloc[0],marker='o',ms=3,label=p,color=colors[p])
ax.axhline(100,color='0.7',lw=.7);ax.set(xlabel='Year',ylabel='Fixed station concentration index (2019 = 100)',xticks=range(2019,2026,2));ax.legend(ncol=5,frameon=False,loc='upper center',bbox_to_anchor=(.5,1.17));fig.tight_layout();fig.savefig(O/'Figure_1.png');plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(7.1,4.0),sharey=True)
order=list(end.sort_values(('PM2.5',2025)).index)
for ax,p in zip(axs,['PM10','PM2.5']):
 yy=np.arange(11);b=end.loc[order,(p,2019)];e=end.loc[order,(p,2025)]
 ax.hlines(yy,e,b,color='0.72',lw=1.3);ax.scatter(b,yy,c='#A9B4BC',label='2019',s=22);ax.scatter(e,yy,c=colors[p],label='2025',s=25)
 ax.set_yticks(yy,order);ax.set_xlabel(p+' (µg/m³)');ax.invert_yaxis();ax.legend(frameon=False,fontsize=8)
fig.tight_layout();fig.savefig(O/'Figure_2.png');plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(7.1,3.5))
for p in P:
 z=c[c.pollutant==p].groupby('year').value.agg(['mean','std']);z['std']=c[c.pollutant==p].groupby('year').value.apply(lambda a:a.std(ddof=0))
 axs[0].plot(z.index,z['std'],label=p,color=colors[p]);axs[1].plot(z.index,z['std']/z['mean'],label=p,color=colors[p])
axs[0].set(ylabel='Between-city standard deviation (µg/m³)',xlabel='Year');axs[1].set(ylabel='Between-city coefficient of variation',xlabel='Year');axs[1].legend(frameon=False,fontsize=8);fig.tight_layout();fig.savefig(O/'Figure_3.png');plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(7.1,3.6))
for ax,p in zip(axs,['PM2.5','O3']):
 ax.scatter(E.gdp_pc_cny2024/1000,E[p],color=colors[p],s=28)
 for _,r in E.iterrows():ax.annotate({'Hong Kong':'HK','Macao':'MC','Guangzhou':'GZ','Shenzhen':'SZ','Zhuhai':'ZH','Foshan':'FS','Huizhou':'HZ','Dongguan':'DG','Zhongshan':'ZS','Jiangmen':'JM','Zhaoqing':'ZQ'}[r.city],(r.gdp_pc_cny2024/1000,r[p]),xytext=({'PM2.5':{'Foshan':(4,-10),'Huizhou':(4,-10),'Dongguan':(0,6),'Zhongshan':(-11,-10),'Jiangmen':(-12,5)},'O3':{'Zhaoqing':(-6,7),'Zhongshan':(-8,-12),'Huizhou':(3,5),'Dongguan':(-9,7),'Zhuhai':(-8,-12),'Jiangmen':(-10,-12)}}.get(p,{}).get(r.city,(3,3))),textcoords='offset points',fontsize=7)
 ax.set(xlabel='2024 GDP per capita (thousand CNY)',ylabel=p+' in 2024 (µg/m³)');ax.margins(x=.15,y=.18)
fig.tight_layout();fig.savefig(O/'Figure_5.png');plt.close(fig)
fig,ax=plt.subplots(figsize=(6.6,3.8));d=mo[(mo.year.isin([2024,2025]))&(mo.pollutant=='PM10')].groupby(['year','month']).value.mean().unstack(0)
for y,style in [(2024,'--'),(2025,'-')]:ax.plot(d.index,d[y],style,marker='o',label=str(y),color='#89959D' if y==2024 else colors['PM10'])
ax.axvspan(3.65,4.35,color='#E8D5BE',alpha=.6);ax.set(xlabel='Month',ylabel='Mean of 11 city station means of PM10 (µg/m³)',xticks=range(1,13));ax.legend(frameon=False);fig.tight_layout();fig.savefig(O/'Figure_6.png');plt.close(fig)
fig,ax=plt.subplots(figsize=(6.6,4));mat=pd.read_csv(O/'monthly_comovement_PM2.5.csv',index_col=0).loc[order,order];im=ax.imshow(mat,vmin=-1,vmax=1,cmap='RdBu_r');ax.set_xticks(range(11),order,rotation=60,ha='right',fontsize=8);ax.set_yticks(range(11),order,fontsize=8);fig.colorbar(im,ax=ax,label='Spearman correlation of monthly anomaly changes',shrink=.85);fig.tight_layout();fig.savefig(O/'Figure_7.png');plt.close(fig)
print('annual observations',a.value.count(),'fixed18',fixed.value.count(),'monthly',monthly.shape[0])
for file in ['trend_sensitivity.csv','city_dispersion_summary.csv','economic_rank_associations.csv','monthly_comovement_summary.csv']:
 print(file);print(pd.read_csv(O/file).round(4).to_string(index=False))
