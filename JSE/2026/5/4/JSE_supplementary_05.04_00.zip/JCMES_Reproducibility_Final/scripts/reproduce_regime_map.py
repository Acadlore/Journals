from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json
import numpy as np,pandas as pd
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv',parse_dates=['timestamp']);SEL=pd.read_csv(ROOT/'processed_inputs'/'stress_days_selected.csv');dates=pd.to_datetime(SEL.date).dt.date.tolist();DT=.25;rows=[]
for E in [140.,70.,35.,20.,10.,5.]:
 for date in dates:
  x=D[D.timestamp.dt.date==date];pv=x.pv_ac_mw.to_numpy(float);n=len(pv);pcap=.85*m.ERATE;pmax=30.;ach=np.full(n,.98*DT/E);adis=np.full(n,DT/(.98*E));lims=np.full(n,pmax);ch,dis,_=m.solve_lp(pv,DT,pcap,pmax,E,ach,adis,lims,lims);b1=float(np.maximum(pv-pcap-ch,0).sum()*DT)
  for Tb in [5.,15.,25.,35.,40.]:
   amb=np.full(n,Tb,float);no=m.replay(pv,ch,dis,amb,DT,pmax,E,m.CONFIGS['all_pathA'],m.RTH0,m.CTH0,m.HEAT0);fu=m.replay(pv,ch,dis,amb,DT,pmax,E,m.CONFIGS['all_full'],m.RTH0,m.CTH0,m.HEAT0);no_c=float(np.maximum(pv-pcap-no['ch'],0).sum()*DT);fu_c=float(np.maximum(pv-pcap-fu['ch'],0).sum()*DT)
   rows.append({'date':str(date),'ambient_C':Tb,'E_MWh':E,'duration_h':E/pmax,'P_over_E_per_h':pmax/E,'B1_curt_MWh':b1,'noheat_curt_MWh':no_c,'full_curt_MWh':fu_c,'self_heating_deltaTmax_C':float(np.max(fu['T']-Tb)),'full_maxT_C':float(fu['T'].max()),'full_maxI_A':float(np.abs(fu['I']).max()),'full_charge_clip_intervals':int((fu['ch']+1e-8<ch).sum()),'max_charge_current_util_pct':float(100*np.max(np.maximum(fu['I'],0))/m.ICH)})
out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);R=pd.DataFrame(rows);R.to_csv(out/'regime_map_daily.csv',index=False);S=R.groupby(['ambient_C','E_MWh','duration_h','P_over_E_per_h'],as_index=False).agg(B1_curt_MWh_16d=('B1_curt_MWh','sum'),noheat_curt_MWh_16d=('noheat_curt_MWh','sum'),full_curt_MWh_16d=('full_curt_MWh','sum'),self_heating_deltaTmax_C=('self_heating_deltaTmax_C','max'),full_maxT_C=('full_maxT_C','max'),full_maxI_A=('full_maxI_A','max'),full_charge_clip_intervals=('full_charge_clip_intervals','sum'),max_charge_current_util_pct=('max_charge_current_util_pct','max'));S['ambient_property_gap_MWh_16d']=S.noheat_curt_MWh_16d-S.B1_curt_MWh_16d;S['self_heating_gap_MWh_16d']=S.full_curt_MWh_16d-S.noheat_curt_MWh_16d;S.to_csv(out/'regime_map.csv',index=False);s={'n_combinations':len(S),'combinations_with_charge_clipping':int((S.full_charge_clip_intervals>0).sum()),'max_self_heating_deltaT_C':float(S.self_heating_deltaTmax_C.max()),'max_charge_current_util_pct':float(S.max_charge_current_util_pct.max()),'max_full_temperature_C':float(S.full_maxT_C.max()),'max_abs_self_heating_curtailment_gap_MWh_16d':float(S.self_heating_gap_MWh_16d.abs().max())};(out/'regime_map_summary.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
