from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json, time
import numpy as np, pandas as pd
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');PV=D.pv_ac_mw.to_numpy(float);AMB=D.ambient_C.to_numpy(float);DT=.25

def worker(d):
    sl=slice(d*96,(d+1)*96);pv=PV[sl];amb=AMB[sl];r=m.solve_day(pv,amb,DT,.85,30.,140.,m.CONFIGS['all_full']);sur=np.maximum(pv-.85*m.ERATE,0);head=np.maximum(.85*m.ERATE-pv,0);o={'day':d}
    for name,rr in [('B2',r['rr2']),('B3',r['rr3'])]:
      ce=np.maximum(rr['ch']-sur,0);de=np.maximum(rr['dis']-head,0)
      o.update({f'{name}_charge_violation_intervals':int((ce>1e-8).sum()),f'{name}_discharge_violation_intervals':int((de>1e-8).sum()),f'{name}_charge_excess_MWh':float(ce.sum()*DT),f'{name}_discharge_excess_MWh':float(de.sum()*DT),f'{name}_max_charge_excess_MW':float(ce.max()),f'{name}_max_discharge_excess_MW':float(de.max()),f'{name}_terminal_error':float(abs(rr['soc'][-1]-m.S0))})
    return o
if __name__=='__main__':
    out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);t=time.time()
    with Pool(6) as p: rows=p.map(worker,range(365),chunksize=3)
    df=pd.DataFrame(rows);df.to_csv(out/'constraint_audit_daily.csv',index=False);s={}
    for name in ['B2','B3']:
      s[name]={'charge_violation_intervals':int(df[f'{name}_charge_violation_intervals'].sum()),'discharge_violation_intervals':int(df[f'{name}_discharge_violation_intervals'].sum()),'charge_excess_MWh':float(df[f'{name}_charge_excess_MWh'].sum()),'discharge_excess_MWh':float(df[f'{name}_discharge_excess_MWh'].sum()),'max_charge_excess_MW':float(df[f'{name}_max_charge_excess_MW'].max()),'max_discharge_excess_MW':float(df[f'{name}_max_discharge_excess_MW'].max()),'max_terminal_error':float(df[f'{name}_terminal_error'].max())}
    s['runtime_s']=time.time()-t;(out/'constraint_audit.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
