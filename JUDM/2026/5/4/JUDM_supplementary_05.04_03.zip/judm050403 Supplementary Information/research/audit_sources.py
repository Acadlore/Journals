import pandas as pd,pdfplumber,numpy as np,re,json
x=pd.read_csv('output/station_annual_2019_2025.csv');out=[]
for y in range(2019,2026):
 with pdfplumber.open(f'research/PRD_{y}.pdf') as pdf:
  for pol,g in x[x.year==y].groupby('pollutant',sort=False):
   page=pdf.pages[int(g.iloc[0].source_page)-1];words=page.extract_words()
   heads=[w for w in words if w['text'].lower()=='average' and w['top']<150]
   h=max(heads,key=lambda w:w['x0']);cx=(h['x0']+h['x1'])/2
   vals=[w for w in words if abs((w['x0']+w['x1'])/2-cx)<11 and w['top']>h['bottom'] and w['top']<760 and re.fullmatch(r'\d+(?:\.\d+)?\*{0,2}',w['text'])]
   vals.sort(key=lambda w:w['top'])
   got=[float(w['text'].strip('*')) for w in vals];expect=g.value.tolist()
   flags=[w['text'].count('*') for w in vals];expected_flags=g.flag.tolist()
   match=len(got)==23 and np.allclose(got,expect) and flags==expected_flags
   out.append(dict(year=y,pollutant=pol,pdf_page=int(g.iloc[0].source_page),count=len(got),match=bool(match),independent=got,previous=expect,independent_flags=flags,previous_flags=expected_flags))
print([(r['year'],r['pollutant'],r['count'],r['match']) for r in out])
open('verification/source_audit.json','w').write(json.dumps(out,indent=2))
print('matched tables',sum(r['match'] for r in out),'of',len(out))
