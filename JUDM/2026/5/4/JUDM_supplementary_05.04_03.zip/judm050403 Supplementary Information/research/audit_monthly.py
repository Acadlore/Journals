import pandas as pd,pdfplumber,numpy as np,re,json
x=pd.read_csv('output/station_observations_2019_2025.csv');out=[]
months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];mismatch=[];verified=0
for year in range(2019,2026):
 with pdfplumber.open(f'research/PRD_{year}.pdf') as pdf:
  for pol,g in x[x.year==year].groupby('pollutant',sort=False):
   page=pdf.pages[int(g.iloc[0].source_page)-1];words=page.extract_words()
   h=max([w for w in words if w['text'].lower()=='average' and w['top']<150],key=lambda w:w['x0']);cx=(h['x0']+h['x1'])/2
   annual=[w for w in words if abs((w['x0']+w['x1'])/2-cx)<11 and w['top']>h['bottom'] and w['top']<760 and re.fullmatch(r'\d+(?:\.\d+)?\*{0,2}',w['text'])];annual.sort(key=lambda w:w['top'])
   cent={mo+1:next(((w['x0']+w['x1'])/2 for w in words if w['text']==name and w['top']<150),None) for mo,name in enumerate(months)}
   if any(v is None for v in cent.values()):out.append([year,pol,'headers missing']);continue
   ids=g[g.month==0].station.tolist()
   for s,an in zip(ids,annual):
    for month,xc in cent.items():
     cand=[w for w in words if abs(w['top']-an['top'])<4 and abs((w['x0']+w['x1'])/2-xc)<12 and re.fullmatch(r'(?:\d+(?:\.\d+)?\*{0,2}|--?)',w['text'])]
     row=g[(g.station==s)&(g.month==month)].iloc[0];v=row.value
     if len(cand)==1:
      t=cand[0]['text'];a=np.nan if t in ['-','--'] else float(t.strip('*'))
      if np.isclose(v,a,equal_nan=True) and int(row.flag)==t.count('*'):verified+=1
      else:mismatch.append([year,pol,s,month,float(v),str(a)])
     else:out.append([year,pol,s,month,'ambiguous',len(cand)])
print('verified monthly cells',verified,'of 9660; mismatches',mismatch,'unresolved',len(out));print(out[:30])
open('verification/monthly_source_audit.json','w').write(json.dumps({'verified':verified,'mismatches':mismatch,'unresolved':out},indent=2))
