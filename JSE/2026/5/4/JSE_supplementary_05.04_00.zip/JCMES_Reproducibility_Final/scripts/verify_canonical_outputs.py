from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json, math, pandas as pd
M=json.load(open(ROOT/'canonical_outputs'/'NUMERICAL_MANIFEST.json'));C=json.load(open(ROOT/'canonical_outputs'/'central_results.json'));F=json.load(open(ROOT/'figures'/'FIGURE_TRACEABILITY.json'));A=json.load(open(ROOT/'audit'/'final_assertion_audit.json'))
def close(a,b,t=1e-8): return math.isclose(float(a),float(b),rel_tol=0,abs_tol=t)
checks=[]
def ck(name,ok,detail=None):checks.append((name,bool(ok),detail))
ck('final_assertion_audit',A.get('all_passed') is True,A.get('n_checks'))
for k in ['B0_MWh','B1_MWh','B2raw_MWh','B2_MWh','B3_MWh','B3_fixed25_MWh','B3_pathA_MWh','PathA_effect_MWh','PathB_raw_MWh']:
 ck('central_'+k,close(C[k],M['central'][k]),[C[k],M['central'][k]])
ck('figure5_fixed25',close(F['Figure5_fixed25_GWh']*1000,M['central']['B3_fixed25_MWh'],1e-6),F['Figure5_fixed25_GWh'])
ck('figure5_pathA',close(F['Figure5_pathA_GWh']*1000,M['central']['B3_pathA_MWh'],1e-6),F['Figure5_pathA_GWh'])
ck('figure5_full',close(F['Figure5_full_GWh']*1000,M['central']['B3_MWh'],1e-6),F['Figure5_full_GWh'])
ck('figure6_clips',F['Figure6_clipped_combinations']==M['regime_map']['combinations_with_charge_clipping'],F['Figure6_clipped_combinations'])
ck('figure6_deltaT',close(F['Figure6_max_deltaT_C'],M['regime_map']['max_self_heating_deltaT_C'],1e-8),F['Figure6_max_deltaT_C'])
ck('figure6_util',close(F['Figure6_max_util_pct'],M['regime_map']['max_charge_current_util_pct'],1e-8),F['Figure6_max_util_pct'])
failed=[x for x in checks if not x[1]]
print('\n'.join(f"{'PASS' if ok else 'FAIL'} {name}: {detail}" for name,ok,detail in checks))
if failed: raise SystemExit(1)
