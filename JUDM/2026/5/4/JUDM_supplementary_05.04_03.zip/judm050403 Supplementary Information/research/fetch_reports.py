import requests,re,concurrent.futures,pathlib
base='https://www.epd.gov.hk'
s=requests.get(base+'/epd/english/resources_pub/publications/m_report.html').text
links=re.findall(r'<a\b[^>]*href=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</a>',s,re.S)
items=[]
for u,t in links:
 t=re.sub('<[^>]+>','',t)
 m=re.search(r'Report for Year (20\d\d)',t)
 if m and 2019<=int(m[1])<=2025:items.append((int(m[1]),u if u.startswith('http') else base+u))
def fetch(it):
 y,u=it;r=requests.get(u);r.raise_for_status();pathlib.Path(f'research/PRD_{y}.pdf').write_bytes(r.content);return y,len(r.content)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as p:print(list(p.map(fetch,items)))
pathlib.Path('research/report_sources.txt').write_text('\n'.join(f'{y}\t{u}' for y,u in sorted(items)))
