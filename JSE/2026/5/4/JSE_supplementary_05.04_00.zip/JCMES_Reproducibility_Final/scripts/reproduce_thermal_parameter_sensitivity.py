from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json
import pandas as pd
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');PV=D.pv_ac_mw.to_numpy(float);AMB=D.ambient_C.to_numpy(float);DT=.25;PARAM=None;FACTOR=None;CFG=None

def worker(d):
 sl=slice(d*96,(d+1)*96);rth=m.RTH0*(FACTOR if PARAM=='rth' else 1);cth=m.CTH0*(FACTOR if PARAM=='cth' else 1);kap=m.HEAT0*(FACTOR if PARAM=='kappa' else 1);r=m.solve_day(PV[sl],AMB[sl],DT,.85,30.,140.,m.CONFIGS[CFG],rth,cth,kap);return float(r['b3'].sum()*DT),int(r['first_conv_it0'] is not None),float(abs(r['rr3']['soc'][-1]-m.S0))
if __name__=='__main__':
 rows=[]
 for param in ['rth','cth','kappa']:
  for fac in [.8,1.2]:
   vals={}
   for cfg in ['all_pathA','all_full']:
    PARAM=param;FACTOR=fac;CFG=cfg
    with Pool(6) as p:r=p.map(worker,range(365),chunksize=3)
    vals[cfg]=r
   pa=sum(x[0] for x in vals['all_pathA']);fu=sum(x[0] for x in vals['all_full']);rows.append({'parameter':param,'factor':fac,'pathA_B3_MWh':pa,'full_B3_MWh':fu,'PathB_raw_MWh':fu-pa,'pathA_converged_blocks':sum(x[1] for x in vals['all_pathA']),'full_converged_blocks':sum(x[1] for x in vals['all_full']),'max_terminal_error':max(max(x[2] for x in vals['all_pathA']),max(x[2] for x in vals['all_full']))})
 out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);df=pd.DataFrame(rows);df.to_csv(out/'thermal_parameter_sensitivity.csv',index=False);print(df.to_string(index=False))
