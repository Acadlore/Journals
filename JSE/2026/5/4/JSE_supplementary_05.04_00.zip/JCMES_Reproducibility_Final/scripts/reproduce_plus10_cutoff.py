from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import pandas as pd, numpy as np
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');PV=D.pv_ac_mw.to_numpy(float);AMB=D.ambient_C.to_numpy(float)+10.;DT=.25;P=None

def worker(d):
 sl=slice(d*96,(d+1)*96);pv=PV[sl];amb=AMB[sl];r=m.solve_day(pv,amb,DT,.85,P,140.,m.CONFIGS['all_full']);preT=np.r_[amb[0],r['rr3']['T'][:-1]];mask=preT>=m.TMAX;return {'B1_MWh':float(r['b1'].sum()*DT),'raw_MWh':float(r['b2raw'].sum()*DT),'B2_MWh':float(r['b2'].sum()*DT),'B3_MWh':float(r['b3'].sum()*DT),'max_boundary_C':float(amb.max()),'max_B3_T_C':float(r['rr3']['T'].max()),'cutoff_intervals':int(mask.sum()),'max_abs_power_cutoff_MW':float(np.max(np.abs(r['rr3']['ch'][mask])+np.abs(r['rr3']['dis'][mask]))) if mask.any() else 0.0}
if __name__=='__main__':
 rows=[]
 for pmax in [15.,30.,60.]:
  P=pmax
  with Pool(6) as p:r=p.map(worker,range(365),chunksize=3)
  x=pd.DataFrame(r);rows.append({'P_MW':pmax,'B1_curt_GWh':x.B1_MWh.sum()/1000,'raw_replay_curt_GWh':x.raw_MWh.sum()/1000,'raw_B1_to_replay_gap_MWh':(x.raw_MWh-x.B1_MWh).sum(),'B2_curt_GWh':x.B2_MWh.sum()/1000,'B3_curt_GWh':x.B3_MWh.sum()/1000,'max_boundary_C':x.max_boundary_C.max(),'max_B3_T_C':x.max_B3_T_C.max(),'cutoff_hours':x.cutoff_intervals.sum()*DT,'max_abs_power_while_preT_ge55_MW':x.max_abs_power_cutoff_MW.max()})
 out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);df=pd.DataFrame(rows);df.to_csv(out/'plus10_cutoff_summary.csv',index=False);print(df.to_string(index=False))
