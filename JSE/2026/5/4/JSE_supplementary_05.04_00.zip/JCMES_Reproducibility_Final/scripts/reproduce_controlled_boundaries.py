from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json,time
import numpy as np,pandas as pd
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');PV=D.pv_ac_mw.to_numpy(float);DT=.25;BOUND=None;CFG=None

def worker(d):
    sl=slice(d*96,(d+1)*96);pv=PV[sl];amb=np.full(96,BOUND,float);r=m.solve_day(pv,amb,DT,.85,30.,140.,m.CONFIGS[CFG]);return float(r['b3'].sum()*DT),float(r['rr3']['T'].max()),float(np.abs(r['rr3']['I']).max())
if __name__=='__main__':
    out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);rows=[]
    for b in [25.,30.,35.]:
      vals={}
      for cfg in ['all_pathA','all_full']:
        BOUND=b;CFG=cfg;t=time.time()
        with Pool(6) as p:r=p.map(worker,range(365),chunksize=3)
        vals[cfg]=r
      pa=sum(x[0] for x in vals['all_pathA']);fu=sum(x[0] for x in vals['all_full']);rows.append({'boundary_C':b,'all_pathA_MWh':pa,'all_full_MWh':fu,'selfheat_raw_MWh':fu-pa,'maxT_C':max(x[1] for x in vals['all_full']),'max_selfheat_rise_C':max(x[1] for x in vals['all_full'])-b,'maxI_A':max(x[2] for x in vals['all_full'])})
    df=pd.DataFrame(rows);df.to_csv(out/'controlled_boundary_sensitivity.csv',index=False);print(df.to_string(index=False))
