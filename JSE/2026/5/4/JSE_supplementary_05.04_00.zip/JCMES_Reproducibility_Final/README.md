# Reproducibility package

## Manuscript
**Electrothermal Pathways and Model Adequacy for Curtailment Recovery in Export-Constrained Photovoltaic Battery Energy Storage Systems**

This package contains the computational materials used to reproduce the numerical results, validation calculations, sensitivity analyses, and final figures reported in the manuscript.

### Canonical model
`scripts/electrothermal_model.py`

The representative-cell population is normalized so that the identified 25 °C OCV-integrated energy over SOC 0.10–0.90 is exactly 112 MWh for the 140 MWh label case. Terminal-SOC repair respects the instantaneous PV-surplus and export-headroom constraints. B3 uses the sequential-linearization procedure described in the manuscript.

## Interpretation of the reported pathways

- Path A at the nominal exposed representative-cell boundary is **265.602 MWh/year**.
- The raw nominal full-minus-no-self-heating difference is about **0.128 MWh/year**, but it is below the numerical resolution established by the solver-robustness tests and is retained only as a diagnostic.
- B2→B3 is a **re-optimization effect under the nonlinear physical battery representation**, not a direct thermal benefit.
- B3 is a numerically robust sequential-linearization solution at the reported annual scale; it is not presented as a globally proven nonlinear optimum.
- The 16-day five-minute comparison is a selected stressed-day sensitivity, not an annual temporal-resolution validation.
- The regime map contains charge clipping in 19/30 combinations and is interpreted as a thermal-amplification/current-utilization diagnostic.
- The exposed-cell Path-A magnitude is not a prediction of an HVAC-managed commercial BESS.

## Package structure

- `processed_inputs/`: final 15-minute and native five-minute PV/weather inputs, the original NSRDB source CSV, and the 16 selected stress days.
- `battery_model/`: identified OCV, resistance, capacity, RC, and thermal parameters.
- `validation_raw/`: held-out 25 °C and 35 °C UDDS source profiles used for validation.
- `canonical_outputs/`: compact result summaries and the full-precision numerical manifest.
- `supporting_outputs/`: detailed daily and trajectory outputs supporting the compact summaries.
- `audit/`: numerical constraint and assertion checks for the packaged implementation.
- `figures/`: Figures 1–6 in high-resolution PNG, editable SVG, and vector PDF formats, plus supporting traceability data.
- `scripts/`: canonical model and reproduction scripts.

## Environment

```bash
python -m pip install -r requirements.txt
```

SciPy's HiGHS backend is used for the linear subproblems.

## Reconstructing the processed PV/weather series

The included NSRDB source CSV can be converted to the packaged five-minute and 15-minute dispatch inputs:

```bash
python scripts/reconstruct_pv.py
```

The reconstructed numerical columns match `processed_inputs/recon_pv5.csv` and `processed_inputs/recon_pv15.csv`.

## Quick verification

```bash
python scripts/verify_canonical_outputs.py
python scripts/smoke_test.py
```

`verify_canonical_outputs.py` cross-checks the numerical manifest, central-results file, verification assertions, and figure traceability.

## Reproduction commands

Run from the package root. Annual calculations may take several minutes depending on hardware.

```bash
# Nominal B0/B1/raw replay/B2/B3 + fixed-25 °C, Path A and full B3
python scripts/reproduce_nominal_pathways.py

# POI surplus/headroom audit
python scripts/reproduce_constraint_audit.py

# Full held-out UDDS validation
python scripts/reproduce_validation.py

# Q(T) empirical-map sensitivity
python scripts/reproduce_capacity_map_sensitivity.py

# 45 °C identification-domain attribution and cap sensitivity
python scripts/reproduce_domain45_sensitivity.py

# B2-initialization and extended-iteration robustness
python scripts/reproduce_convergence_sensitivity.py

# Constant 25/30/35 °C boundary sensitivity
python scripts/reproduce_controlled_boundaries.py

# 16 selected-day 15-min versus native 5-min sensitivity
python scripts/reproduce_resolution_16days.py

# Within-domain thermal/current-utilization regime map
python scripts/reproduce_regime_map.py

# 48-hour horizon sensitivity
python scripts/reproduce_horizon48.py

# ±20% Rth/Cth/kappa diagnostic sensitivity
python scripts/reproduce_thermal_parameter_sensitivity.py

# +10 °C cutoff behavior
python scripts/reproduce_plus10_cutoff.py

# Regenerate final figures where supported by the packaged numerical outputs
python scripts/generate_figures.py
```

Regenerated numerical files are written to `reproduced_outputs/`; regenerated figures are written to `reproduced_figures/`. Canonical outputs are not overwritten.

## Traceability map

| Manuscript result | Canonical file | Reproduction script |
|---|---|---|
| Processed PV/weather inputs | `processed_inputs/recon_pv5.csv`, `recon_pv15.csv` | `reconstruct_pv.py` |
| B0/B1/raw replay/B2/B3 | `canonical_outputs/central_results.json` | `reproduce_nominal_pathways.py` |
| Exact 112 MWh energy window | `canonical_outputs/exact_energy_normalization.json` | encoded in `electrothermal_model.py` |
| POI-safe repair | `audit/plant_constraints_audit_final.json` | `reproduce_constraint_audit.py` |
| Fixed-25 / Path A / Path B | `canonical_outputs/central_results.json` | `reproduce_nominal_pathways.py` |
| Held-out validation | `canonical_outputs/validation_summary.json` | `reproduce_validation.py` |
| 45 °C domain sensitivity | `canonical_outputs/domain45_sensitivity.json` | `reproduce_domain45_sensitivity.py` |
| Convergence / initialization / extended iterations | `canonical_outputs/convergence_full.json`, `extended_iteration_sensitivity.json` | `reproduce_convergence_sensitivity.py` |
| Q(T) sensitivity | `canonical_outputs/capacity_map_sensitivity.json` | `reproduce_capacity_map_sensitivity.py` |
| Controlled boundaries | `canonical_outputs/controlled_boundary_sensitivity.csv` | `reproduce_controlled_boundaries.py` |
| 16-day resolution | `canonical_outputs/resolution_16_stress_days.json` | `reproduce_resolution_16days.py` |
| Regime map | `canonical_outputs/regime_map.csv`, `regime_map_summary.json` | `reproduce_regime_map.py` |
| 48-hour horizon | `canonical_outputs/horizon48_summary.csv` | `reproduce_horizon48.py` |
| Thermal-parameter sensitivity | `canonical_outputs/thermal_parameter_sensitivity.csv` | `reproduce_thermal_parameter_sensitivity.py` |
| 55 °C cutoff behavior | `canonical_outputs/plus10_cutoff_summary.csv` | `reproduce_plus10_cutoff.py` |
| Figures | `figures/` | `generate_figures.py` |

## Data provenance

Solar and meteorological inputs derive from the 2023 NSRDB GOES CONUS PSM v4 Phoenix-area record described in the manuscript. Battery parameters derive from the public A123 ANR26650M1-B LFP dataset cited in the manuscript. The two held-out UDDS validation profiles are included to permit direct recalculation of the validation metrics.

## Numerical precision

Canonical files retain full floating-point precision for traceability. Manuscript values are rounded to scientifically appropriate precision. Sub-MWh self-heating differences are retained as diagnostics only and are not treated as physically resolved effects.
