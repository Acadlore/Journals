from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json
import pandas as pd
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');x=D.iloc[:96];r=m.solve_day(x.pv_ac_mw.to_numpy(float),x.ambient_C.to_numpy(float),.25,.85,30.,140.,m.CONFIGS['all_full']);print(json.dumps({'day':'2023-01-01','B3_MWh':float(r['b3'].sum()*.25),'terminal_SOC':float(r['rr3']['soc'][-1]),'n_replays':int(r['n_replays']),'lp_failed':bool(r['lp_failed'])},indent=2))
