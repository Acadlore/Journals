from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json
import numpy as np,pandas as pd
import electrothermal_model as m
sel=pd.read_csv(ROOT/'processed_inputs'/'stress_days_selected.csv');dates=pd.to_datetime(sel.date).dt.date.tolist()
D15=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv',parse_dates=['timestamp']);D5=pd.read_csv(ROOT/'processed_inputs'/'recon_pv5.csv',parse_dates=['timestamp'])
rows=[]
for date in dates:
    a=D15[D15.timestamp.dt.date==date];b=D5[D5.timestamp.dt.date==date]
    r15=m.solve_day(a.pv_ac_mw.to_numpy(float),a.ambient_C.to_numpy(float),.25,.85,30.,140.,m.CONFIGS['all_full'])
    r5=m.solve_day(b.pv_ac_mw.to_numpy(float),b.ambient_C.to_numpy(float),1/12,.85,30.,140.,m.CONFIGS['all_full'])
    c15=float(r15['b3'].sum()*.25);c5=float(r5['b3'].sum()/12);p15=float(r15['rr3']['T'].max());p5=float(r5['rr3']['T'].max())
    rows.append({'date':str(date),'curtailment_15min_MWh':c15,'curtailment_5min_MWh':c5,'difference_MWh':c5-c15,'peakT_15min_C':p15,'peakT_5min_C':p5,'peakT_difference_C':p5-p15,'terminal_error_15min':abs(r15['rr3']['soc'][-1]-m.S0),'terminal_error_5min':abs(r5['rr3']['soc'][-1]-m.S0)})
out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);df=pd.DataFrame(rows);df.to_csv(out/'resolution_16days_daily.csv',index=False);s={'n_days':len(df),'curtailment_15min_MWh':float(df.curtailment_15min_MWh.sum()),'curtailment_5min_MWh':float(df.curtailment_5min_MWh.sum()),'difference_MWh':float(df.difference_MWh.sum()),'difference_pct_of_15min':float(100*df.difference_MWh.sum()/df.curtailment_15min_MWh.sum()),'max_abs_daily_difference_MWh':float(df.difference_MWh.abs().max()),'mean_abs_daily_difference_MWh':float(df.difference_MWh.abs().mean()),'max_abs_peakT_difference_C':float(df.peakT_difference_C.abs().max()),'max_terminal_error':float(max(df.terminal_error_15min.max(),df.terminal_error_5min.max())),'interpretation':'Selected stressed-day sensitivity only; not an annual temporal-resolution validation.'};(out/'resolution_16days.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
