"""Reproducible full-trajectory held-out UDDS validation.

Uses every raw sample in A002_UDDS_P25.mat and A002_UDDS_P35.mat.
No filtering, resampling, offset correction, or sample exclusion is applied.

Dynamic validation model:
  z[k+1]  = z[k] + I[k] dt / (3600 Q(T[k]))
  v1[k+1] = exp(-dt/tau) v1[k] + (1-exp(-dt/tau)) I[k] R1(T[k])
  V[k]    = Uoc(z[k],T[k]) + I[k] R0(z[k],T[k]) + v1[k]
  q[k]    = kappa * ( I[k]^2 R0(z[k],T[k]) + I[k] v1[k] )
  T[k+1]  = a T[k] + (1-a) [Tf[k] + Rth q[k]], a=exp(-dt/(Rth*Cth))

The heat expression is the reduced Bernardi irreversible term for the retained
polarization state; under quasi-steady polarization v1=I*R1 it reduces to the
annual model's kappa*I^2*(R0+R1).
"""
from pathlib import Path
import json, math, sys
import numpy as np
import pandas as pd
from scipy.io import loadmat

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
ORIG=ROOT  # revised package contains the parameter maps and model script
RAW=ROOT/'validation_raw'
sys.path.insert(0,str(ROOT/'scripts'))
import electrothermal_model as e

TAU=e.rc0['tau_s'].to_numpy(float)

def tau_at(T):
    return float(np.interp(np.clip(T,e.rcT[0],e.rcT[-1]),e.rcT,TAU))

def load_profile(temp):
    fn=RAW/f'A002_UDDS_P{temp}.mat'
    d=loadmat(fn,squeeze_me=True,struct_as_record=False)['Data']
    t=np.asarray(d.time,float)
    I=np.asarray(d.current,float)
    V=np.asarray(d.voltage,float)
    Ts=np.asarray(getattr(d,'Ts1' if temp==25 else 'Ts'),float)
    Tf=np.asarray(d.Tf,float)
    return fn,t,I,V,Ts,Tf

def simulate(temp):
    fn,t,I,Vm,Tm,Tf=load_profile(temp)
    n=len(t)
    z=np.empty(n); v1=np.empty(n); Tp=np.empty(n); Vp=np.empty(n)
    # Test begins at the fully charged end of the protocol; initial OCV is also
    # consistent with the upper end of the identified OCV map.
    z[0]=1.0
    v1[0]=0.0
    # State initialization only; no offset correction is applied afterward.
    Tp[0]=Tm[0]
    U0=e.ss(e.O,z[0],Tp[0]); R00=e.ss(e.R0M,z[0],Tp[0])
    Vp[0]=U0+I[0]*R00+v1[0]
    for k in range(n-1):
        dt=float(t[k+1]-t[k])
        T=float(Tp[k]); zk=float(z[k]); ik=float(I[k])
        U=e.ss(e.O,zk,T); R0=e.ss(e.R0M,zk,T); R1=e.r1(T); Q=e.cap(T); tau=tau_at(T)
        # Temperature update from complete raw trajectory.
        q=e.HEAT0*(ik*ik*R0 + ik*v1[k])
        aT=math.exp(-dt/(e.RTH0*e.CTH0))
        Tp[k+1]=aT*T+(1-aT)*(Tf[k]+e.RTH0*q)
        # Electrical states.
        z[k+1]=np.clip(zk+ik*dt/(3600.0*Q),0.0,1.0)
        ap=math.exp(-dt/tau)
        v1[k+1]=ap*v1[k]+(1-ap)*ik*R1
        U2=e.ss(e.O,z[k+1],Tp[k+1]); R02=e.ss(e.R0M,z[k+1],Tp[k+1])
        Vp[k+1]=U2+I[k+1]*R02+v1[k+1]
    verr=Vp-Vm; terr=Tp-Tm
    metrics={
        'profile':fn.name,'temperature_C':temp,'n_samples':int(n),
        'time_start_s':float(t[0]),'time_end_s':float(t[-1]),
        'evaluated_duration_s':float(t[-1]-t[0]),
        'median_sample_interval_s':float(np.median(np.diff(t))),
        'min_sample_interval_s':float(np.min(np.diff(t))),
        'max_sample_interval_s':float(np.max(np.diff(t))),
        'resampling':'none','filtering':'none','offset_correction':'none','excluded_samples':0,
        'initial_SOC':1.0,'initial_polarization_V':0.0,'initial_temperature_C':float(Tm[0]),
        'voltage_RMSE_V':float(np.sqrt(np.mean(verr**2))),
        'voltage_MAE_V':float(np.mean(np.abs(verr))),
        'voltage_max_abs_error_V':float(np.max(np.abs(verr))),
        'voltage_NRMSE_pct_of_3p3V':float(100*np.sqrt(np.mean(verr**2))/3.3),
        'temperature_RMSE_C':float(np.sqrt(np.mean(terr**2))),
        'temperature_MAE_C':float(np.mean(np.abs(terr))),
        'temperature_max_abs_error_C':float(np.max(np.abs(terr))),
        'Tmax_measured_C':float(np.max(Tm)),'Tmax_predicted_C':float(np.max(Tp)),
    }
    traj=pd.DataFrame({'time_s':t,'time_h':(t-t[0])/3600,'current_A':I,
                       'voltage_measured_V':Vm,'voltage_predicted_V':Vp,
                       'surface_temperature_measured_C':Tm,'surface_temperature_predicted_C':Tp,
                       'boundary_temperature_C':Tf,'SOC_predicted':z,'polarization_V':v1})
    return metrics,traj

if __name__=='__main__':
    out=ROOT/'reproduced_outputs'; out.mkdir(exist_ok=True); out.mkdir(exist_ok=True)
    metrics=[]
    for T in (25,35):
        m,tr=simulate(T);metrics.append(m)
        tr.to_csv(out/f'UDDS_{T}C_full_trajectory_validation.csv',index=False)
    pd.DataFrame(metrics).to_csv(out/'heldout_validation_full_trajectory.csv',index=False)
    (out/'heldout_validation_full_trajectory.json').write_text(json.dumps(metrics,indent=2))
    print(pd.DataFrame(metrics).to_string(index=False))
