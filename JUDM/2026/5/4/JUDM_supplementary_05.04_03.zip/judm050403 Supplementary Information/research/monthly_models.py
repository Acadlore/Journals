import pandas as pd,numpy as np
from scipy.stats import t as student_t
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
x=pd.read_csv('output/station_observations_2019_2025.csv')
ex=['Modiesha','Nanshadawen','Xijiao','Shixia','Zhudong','Duanfen','Tap Mun']
x=x[(x.year>=2019)&(x.month>0)&(~x.station_id.isin(ex))&(x.flag==0)&x.value.notna()]
m=x.groupby(['pollutant','year','month']).value.agg(['mean','count']).reset_index()
assert m['count'].min()>=16
m['t']=(12*(m.year-2019)+m.month-1)/12
m['pandemic2020']=(m.year==2020).astype(int);m['pandemic2021']=(m.year==2021).astype(int)
m['april2025']=((m.year==2025)&(m.month==4)).astype(int)
m['logc']=np.log(m['mean'])
m.to_csv('output/fixed_station_monthly_model_input.csv',index=False)
rows=[]
for p,g in m.groupby('pollutant'):
 for label,bw,z in [('HAC6',6,g),('HAC12',12,g),('HAC18',18,g),('omit2020and2021',12,g[~g.year.isin([2020,2021])])]:
  cols=[np.ones(len(z)),z.t.to_numpy()]+[(z.month==i).astype(float).to_numpy() for i in range(2,13)]+[z.april2025.to_numpy()]
  if label!='omit2020and2021':cols += [z.pandemic2020.to_numpy(),z.pandemic2021.to_numpy()]
  X=np.column_stack(cols);Y=z.logc.to_numpy();n,k=X.shape
  assert np.linalg.matrix_rank(X)==k
  beta=np.linalg.lstsq(X,Y,rcond=None)[0];u=Y-X@beta;xu=X*u[:,None]
  meat=xu.T@xu;calendar=np.rint(12*z.t.to_numpy()).astype(int)
  for i in range(n):
   for j in range(i):
    lag=calendar[i]-calendar[j]
    if 0<lag<=bw:meat+=(1-lag/(bw+1))*(np.outer(xu[i],xu[j])+np.outer(xu[j],xu[i]))
  bread=np.linalg.inv(X.T@X);cov=bread@meat@bread*n/(n-k);se=np.sqrt(cov[1,1]);b=beta[1];critical=student_t.ppf(.975,n-k)
  rows.append(dict(pollutant=p,specification=label,n=n,log_trend=b,annual_pct=100*np.expm1(b),lower95=100*np.expm1(b-critical*se),upper95=100*np.expm1(b+critical*se),p_approx=2*student_t.sf(abs(b/se),n-k),april2025_pct=100*np.expm1(beta[13])))
r=pd.DataFrame(rows);r.to_csv('output/monthly_trend_models.csv',index=False)
print(r.round(4).to_string(index=False))
plt.rcParams.update({'font.family':'Liberation Sans','font.size':10})
fig,ax=plt.subplots(figsize=(6.5,3.1));d=r[r.specification=='HAC12'].set_index('pollutant').loc[['PM10','PM2.5','NO2','SO2','O3']]
yy=np.arange(5);ax.errorbar(d.annual_pct,yy,xerr=np.array([d.annual_pct-d.lower95,d.upper95-d.annual_pct]),fmt='o',color='#185C85',capsize=3);ax.axvline(0,color='0.65',lw=.8);ax.set_yticks(yy,d.index);ax.set_xlabel('Estimated annual concentration change (%) with 95% HAC interval');ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig('output/Figure_4.png',dpi=350)
