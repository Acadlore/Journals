from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json,time
import numpy as np,pandas as pd
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');PV=D.pv_ac_mw.to_numpy(float);AMB=D.ambient_C.to_numpy(float);DT=.25;CFG=None

def worker(b):
 st=b*192;en=min(st+192,len(PV));r=m.solve_day(PV[st:en],AMB[st:en],DT,.85,30.,140.,m.CONFIGS[CFG]);rr=r['rr3'];return {'config':CFG,'block':b,'n_steps':en-st,'B0_MWh':float(r['b0'].sum()*DT),'B1_MWh':float(r['b1'].sum()*DT),'B2raw_MWh':float(r['b2raw'].sum()*DT),'B2_MWh':float(r['b2'].sum()*DT),'B3_MWh':float(r['b3'].sum()*DT),'terminal_error':float(abs(rr['soc'][-1]-m.S0)),'maxT_C':float(rr['T'].max()),'maxI_A':float(np.abs(rr['I']).max()),'n_replays':int(r['n_replays']),'first_conv':r['first_conv_it0'],'lp_failed':bool(r['lp_failed'])}
if __name__=='__main__':
 out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);rows=[]
 for cfg in ['fixed25','all_pathA','all_full']:
  CFG=cfg;t=time.time()
  with Pool(6) as p:r=p.map(worker,range(183),chunksize=2)
  rows.extend(r)
 df=pd.DataFrame(rows);df.to_csv(out/'horizon48_blocks.csv',index=False);summary=[]
 for cfg in ['fixed25','all_pathA','all_full']:
  x=df[df.config==cfg];summary.append({'config':cfg,'blocks':len(x),'B0_MWh':float(x.B0_MWh.sum()),'B1_MWh':float(x.B1_MWh.sum()),'B2raw_MWh':float(x.B2raw_MWh.sum()),'B2_MWh':float(x.B2_MWh.sum()),'B3_MWh':float(x.B3_MWh.sum()),'max_terminal_error':float(x.terminal_error.max()),'maxT_C':float(x.maxT_C.max()),'maxI_A':float(x.maxI_A.max()),'mean_replays':float(x.n_replays.mean()),'converged_blocks':int(x.first_conv.notna().sum()),'lp_failed_blocks':int(x.lp_failed.sum())})
 (out/'horizon48_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
