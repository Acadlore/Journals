GREATER BAY AREA AIR QUALITY ASSESSMENT THROUGH 2025
Supplementary data and reproducibility files

CONTENTS
data/ contains extracted source observations, provenance, the matched 2024 economic records, city abbreviations and 2025 eight-hour ozone percentiles.
results/ contains the numerical outputs corresponding to Tables 1–6 and Figures 1–7. Table 7 presents management recommendations, not a fitted or evaluated intervention model.
figures/ contains Figures 1–7 at 350 dpi.
research/ contains the final extraction, analysis and optional independent source-check scripts.
verification/ contains source-table checks and numerical reproduction checks.
references.txt contains the bibliographic source list.

REPRODUCTION
Use Python 3.11 or later and install requirements.txt in a separate environment.
Run python reproduce.py from this directory. No network connection is needed for calculations from the supplied observations. The final deterministic analysis does not use a random seed, learned model, external weights or simulated observations.
The reproduction writes output/; compare its CSV files with the corresponding files in results/. Minor rendering differences can result from fonts or graphics-library versions.

OPTIONAL SOURCE EXTRACTION AND VERIFICATION
The original seven monitoring PDFs are not included. The URLs and SHA-256 hashes are in data/report_sources.json. Download each to research/PRD_YYYY.pdf, or run python research/fetch_reports.py. Convert each to research/PRD_YYYY.txt using pdftotext -layout (the external Poppler command is required). Run python research/parse_air.py, then run the two analysis scripts from this directory. The independent annual and monthly source checks require pdfplumber and the downloaded PDFs; run research/audit_sources.py and research/audit_monthly.py after generating output/.
The official statistical-yearbook PDF and all journal full texts are also not redistributed. Their source URLs and DOI links are supplied. No external model files are required.

DATA DEFINITIONS AND SAMPLES
month=0 denotes the published annual column; months 1–12 denote published monthly columns. All five pollutant concentrations use micrograms per cubic metre. Annual values were not reconstructed from rounded monthly means.
flag is the number of asterisks attached to the source value. Missing entries and flags remain in the extracted data. Consult each source report for the corresponding note. source_page is the one-based PDF page, which can differ from the printed page label.
The primary annual panel contains 805 values. There are 9,660 possible monthly source cells. No missing concentrations were interpolated. The independently checked values and asterisk flags matched the original table cells.
Wanqingsha/Nansha-HKUST and Liyuan/Tongxinling were reconciled as documented renamings. The conservative 18-station sample excludes Modiesha/Nanshadawen, Xijiao/Shixia, Zhudong, Duanfen and Tap Mun. Monthly regional models use 16–18 unflagged observed station values per month.
The 2024 economic comparison matches 2024 city station means. The official table's common-currency GDP figures were used directly. GDP growth and total GDP were retained as context and were not trend-model regressors.

METHODS AND RESULT CORRESPONDENCE
Table 2 uses trend_sensitivity.csv; Table 3 uses city_station_means_2019_2025.csv; Table 4 uses city_dispersion_summary.csv; Table 5 uses monthly_trend_models.csv; Table 6 uses economic_rank_associations.csv. Table 1 describes the supplied data and sample sizes.
The regional monthly logarithmic trend model includes elapsed years, month indicators, separate 2020 and 2021 indicators, and April 2025. NumPy least squares, Bartlett-weighted Newey–West covariance with 12-month bandwidth, n/(n-k) correction and Student t critical values define the principal estimates and approximate intervals. Six- and 18-month bandwidths and exclusion of 2020–2021 provide sensitivity checks. The omission specification uses actual calendar distances in covariance weights.
Monthly co-movement requires at least 80 paired changes in deseasonalised anomalies. Eligible city pairs number 54 for PM10, PM2.5 and SO2, 55 for NO2 and 45 for O3; blank cells fail that completeness rule.
The April indicator is a calendar anomaly, not an identified mineral-dust fraction. The official network PM10 means before and after the event adjustment are 35 and 33 micrograms per cubic metre. No synthetic station-level event adjustment is supplied.
No causal economic effect, policy treatment effect, environmental Kuznets turning point, atmospheric transport fraction, population-weighted exposure or health burden is estimated.


PROVENANCE
Data provenance and third-party reuse conditions are recorded in PROVENANCE.txt. SHA256.json records the distributed files, excluding the manifest itself. Files generated in output/ are not included in the distributed archive.
