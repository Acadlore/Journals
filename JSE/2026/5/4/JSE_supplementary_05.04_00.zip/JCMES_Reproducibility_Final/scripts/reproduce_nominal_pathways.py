from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json, time
import numpy as np, pandas as pd
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv')
PV=D.pv_ac_mw.to_numpy(float); AMB=D.ambient_C.to_numpy(float); DT=.25

def worker(arg):
    cfg,d=arg; sl=slice(d*96,(d+1)*96)
    r=m.solve_day(PV[sl],AMB[sl],DT,.85,30.,140.,m.CONFIGS[cfg])
    rr=r['rr3']
    return {'config':cfg,'day':d,
      'B0_MWh':float(r['b0'].sum()*DT),'B1_MWh':float(r['b1'].sum()*DT),
      'B2raw_MWh':float(r['b2raw'].sum()*DT),'B2_MWh':float(r['b2'].sum()*DT),'B3_MWh':float(r['b3'].sum()*DT),
      'n_replays':int(r['n_replays']),'first_conv_it0':r['first_conv_it0'],'lp_failed':bool(r['lp_failed']),
      'best_it0':int(r['b3_iter']),'best_clip':int(r['best_clip']),'best_term':float(r['best_term']),
      'final_terminal_error':float(abs(rr['soc'][-1]-m.S0)),'maxT_C':float(rr['T'].max()),'n_T_gt45':int((rr['T']>45).sum())}

def summarize(df,cfg):
    x=df[df.config==cfg]
    return {'config':cfg,'B0_MWh':float(x.B0_MWh.sum()),'B1_MWh':float(x.B1_MWh.sum()),
      'B2raw_MWh':float(x.B2raw_MWh.sum()),'B2_MWh':float(x.B2_MWh.sum()),'B3_MWh':float(x.B3_MWh.sum()),
      'converged_blocks':int(x.first_conv_it0.notna().sum()),'converged_pct':float(100*x.first_conv_it0.notna().mean()),
      'mean_replays':float(x.n_replays.mean()),'max_replays':int(x.n_replays.max()),'limit_blocks':int((x.n_replays==10).sum()),
      'lp_failed_blocks':int(x.lp_failed.sum()),'earlier_candidate_retained_blocks':int((x.best_it0 < x.n_replays-1).sum()),
      'max_terminal_error':float(x.final_terminal_error.max()),'maxT_C':float(x.maxT_C.max()),'hours_above45':float(x.n_T_gt45.sum()*DT)}

if __name__=='__main__':
    out=ROOT/'reproduced_outputs'; out.mkdir(exist_ok=True)
    t=time.time(); cfgs=['fixed25','all_pathA','all_full']
    with Pool(min(6,3*2)) as p: rows=p.map(worker,[(c,d) for c in cfgs for d in range(365)],chunksize=3)
    df=pd.DataFrame(rows).sort_values(['config','day'])
    for c in cfgs: df[df.config==c].to_csv(out/f'annual_{c}_daily.csv',index=False)
    sums={c:summarize(df,c) for c in cfgs}
    full=sums['all_full']; fixed=sums['fixed25']; pa=sums['all_pathA']
    summary={'central':full,'fixed25_B3_MWh':fixed['B3_MWh'],'pathA_B3_MWh':pa['B3_MWh'],
      'PathA_MWh':pa['B3_MWh']-fixed['B3_MWh'],'PathB_raw_MWh':full['B3_MWh']-pa['B3_MWh'],
      'B2_to_B3_reoptimization_MWh':full['B2_MWh']-full['B3_MWh'],'runtime_s':time.time()-t}
    (out/'nominal_pathways_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
