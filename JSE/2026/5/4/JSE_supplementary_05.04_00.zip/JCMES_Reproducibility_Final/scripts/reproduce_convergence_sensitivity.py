from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json,time
import numpy as np,pandas as pd
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');PV=D.pv_ac_mw.to_numpy(float);AMB=D.ambient_C.to_numpy(float);DT=.25

def solve_with_init(day,init='b1',maxiter=10):
    sl=slice(day*96,(day+1)*96);pv=PV[sl];amb=AMB[sl];pcap=.85*m.ERATE;pmax=30.;E=140.;n=len(pv);ETA=.98;cfg=m.CONFIGS['all_full']
    ach0=np.full(n,ETA*DT/E);adis0=np.full(n,DT/(ETA*E));lims=np.full(n,pmax);ch1,dis1,_=m.solve_lp(pv,DT,pcap,pmax,E,ach0,adis0,lims,lims)
    if init=='b2':
      raw=m.replay(pv,ch1,dis1,amb,DT,pmax,E,cfg,m.RTH0,m.CTH0,m.HEAT0);ch,dis,_,_=m.terminal_repair(pv,raw['ch'],raw['dis'],amb,DT,pcap,pmax,E,cfg,m.RTH0,m.CTH0,m.HEAT0)
    else: ch,dis=ch1.copy(),dis1.copy()
    cand=[];firstconv=None;lp_failed=False
    for it in range(maxiter):
      rr=m.replay(pv,ch,dis,amb,DT,pmax,E,cfg,m.RTH0,m.CTH0,m.HEAT0);cur=float(np.maximum(pv-pcap-rr['ch'],0).sum()*DT);term=abs(rr['soc'][-1]-m.S0);clip=int((rr['ch']+1e-8<ch).sum()+(rr['dis']+1e-8<dis).sum());cand.append((it,clip,term,cur,rr))
      if clip==0 and term<5e-4 and it>=2 and firstconv is None:firstconv=it
      if firstconv is not None and it>=max(4,firstconv+1):break
      try: chn,disn,_=m.solve_lp(pv,DT,pcap,pmax,E,rr['ach'],rr['adis'],rr['chlim'],rr['dislim'])
      except RuntimeError: lp_failed=True;break
      ch=.5*rr['ch']+.5*chn;dis=.5*rr['dis']+.5*disn
    elig=[c for c in cand if c[0]>=2 and c[1]==0 and c[2]<5e-4]
    best=min(elig,key=lambda c:(c[3],c[2])) if elig else min(([c for c in cand if c[0]>=2] or cand),key=lambda c:(c[1]>0,c[2],c[3]))
    rr=best[4];_,_,rp,_=m.terminal_repair(pv,rr['ch'],rr['dis'],amb,DT,pcap,pmax,E,cfg,m.RTH0,m.CTH0,m.HEAT0);cur=float(np.maximum(pv-pcap-rp['ch'],0).sum()*DT)
    return {'day':day,'b3_MWh':cur,'n_replays':len(cand),'first_conv_it0':firstconv,'lp_failed':lp_failed,'best_it0':best[0],'final_term':abs(rp['soc'][-1]-m.S0)}

def b2worker(d):return solve_with_init(d,'b2',10)
def i25worker(d):return solve_with_init(d,'b1',25)
if __name__=='__main__':
    out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);base=pd.read_csv(ROOT/'supporting_outputs'/'annual_full_daily.csv');t=time.time()
    with Pool(6) as p: b2rows=p.map(b2worker,range(365),chunksize=3)
    b2=pd.DataFrame(b2rows).sort_values('day');b2.to_csv(out/'initialization_B2_daily.csv',index=False)
    nonconv=base.loc[base.first_conv_it0.isna(),'day'].astype(int).tolist()
    with Pool(6) as p: i25rows=p.map(i25worker,nonconv,chunksize=1)
    i25=pd.DataFrame(i25rows).sort_values('day');i25.to_csv(out/'extended_iteration_nonconverged_daily.csv',index=False)
    merged=base[['day','b3_MWh']].merge(i25[['day','b3_MWh','first_conv_it0']],on='day',how='left',suffixes=('_i10','_i25'));merged['filled']=merged.b3_MWh_i25.fillna(merged.b3_MWh_i10)
    s={'B1init_annual_MWh':float(base.b3_MWh.sum()),'B2init_annual_MWh':float(b2.b3_MWh.sum()),'B2init_delta_MWh':float(b2.b3_MWh.sum()-base.b3_MWh.sum()),'B2init_converged_blocks':int(b2.first_conv_it0.notna().sum()),'B2init_mean_replays':float(b2.n_replays.mean()),'B2init_lp_failures':int(b2.lp_failed.sum()),'extended_days':len(nonconv),'newly_converged_by25':int(i25.first_conv_it0.notna().sum()),'still_not_converged_at25':int(i25.first_conv_it0.isna().sum()),'i25_reconstructed_annual_MWh':float(merged.filled.sum()),'i25_delta_MWh':float(merged.filled.sum()-base.b3_MWh.sum()),'runtime_s':time.time()-t}
    (out/'convergence_sensitivity.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
