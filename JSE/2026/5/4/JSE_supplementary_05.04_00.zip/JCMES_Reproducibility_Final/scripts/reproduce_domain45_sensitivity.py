from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json,time,copy
import numpy as np,pandas as pd
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');PV=D.pv_ac_mw.to_numpy(float);AMB=D.ambient_C.to_numpy(float);DT=.25

def worker(d):
    sl=slice(d*96,(d+1)*96);pv=PV[sl];amb=AMB[sl]
    rf=m.solve_day(pv,amb,DT,.85,30.,140.,m.CONFIGS['fixed25']);rp=m.solve_day(pv,amb,DT,.85,30.,140.,m.CONFIGS['all_pathA'])
    cfg=copy.deepcopy(m.CONFIGS['all_pathA']);cfg['thermal_state_cap_C']=45.0;rc=m.solve_day(pv,amb,DT,.85,30.,140.,cfg)
    f=float(rf['b3'].sum()*DT);p=float(rp['b3'].sum()*DT);c=float(rc['b3'].sum()*DT)
    return {'day':d,'fixed25_MWh':f,'pathA_MWh':p,'cap45_MWh':c,'effect_MWh':p-f,'contains_gt45':bool((rp['rr3']['T']>45).any()),'maxT_C':float(rp['rr3']['T'].max())}
if __name__=='__main__':
    out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);t=time.time()
    with Pool(6) as p: rows=p.map(worker,range(365),chunksize=3)
    df=pd.DataFrame(rows).sort_values('day');df.to_csv(out/'domain45_daily.csv',index=False)
    total=float(df.effect_MWh.sum());above=float(df.loc[df.contains_gt45,'effect_MWh'].sum());within=total-above;cap_effect=float(df.cap45_MWh.sum()-df.fixed25_MWh.sum())
    s={'fixed25_B3_MWh':float(df.fixed25_MWh.sum()),'pathA_B3_MWh':float(df.pathA_MWh.sum()),'PathA_MWh':total,'days_exceeding_45C':int(df.contains_gt45.sum()),'effect_on_days_exceeding_45C_MWh':above,'effect_on_days_entirely_le45C_MWh':within,'fraction_on_exceeding_days':above/total,'cap45_PathA_MWh':cap_effect,'cap45_delta_vs_normal_MWh':cap_effect-total,'maxT_C':float(df.maxT_C.max()),'runtime_s':time.time()-t}
    (out/'domain45_sensitivity.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
