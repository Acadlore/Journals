from pathlib import Path
import sys, importlib.util
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'reproduced_figures'
OUT.mkdir(parents=True, exist_ok=True)

# Preserve Figures 1 and 2 when regenerating the numerically driven figures.
import shutil
ORIG = ROOT/'figures'
shutil.copy2(ORIG/'Figure_1.png', OUT/'Figure_1.png')
shutil.copy2(ORIG/'Figure_2.png', OUT/'Figure_2.png')
shutil.copy2(ROOT/'figures/Figure_3.png', OUT/'Figure_3.png')

# Load the canonical electrothermal model.
spec = importlib.util.spec_from_file_location('efinal', ROOT/'scripts/electrothermal_model.py')
e = importlib.util.module_from_spec(spec); spec.loader.exec_module(e)

# ---------------- Figure 4: representative hot day ----------------
df = pd.read_csv(ROOT/'processed_inputs/recon_pv15.csv', parse_dates=['timestamp'])
day = pd.Timestamp('2023-07-20')
sel = df[df['timestamp'].dt.normalize() == day].copy()
assert len(sel) == 96
pv = sel['pv_ac_mw'].to_numpy(float)
amb = sel['ambient_C'].to_numpy(float)
t = sel['timestamp'].to_numpy()
res = e.solve_day(pv, amb, 0.25, 0.85, 30.0, 140.0, e.CONFIGS['all_full'])
rr2, rr3 = res['rr2'], res['rr3']
p2 = rr2['ch'] - rr2['dis']
p3 = rr3['ch'] - rr3['dis']
# SOC state points include the terminal state; align to interval starts for visual comparability.
soc2 = rr2['soc'][:-1]
soc3 = rr3['soc'][:-1]
T2, T3 = rr2['T'], rr3['T']
pcap = 0.85 * e.ERATE

fig, ax = plt.subplots(4, 1, figsize=(8.1, 6.8), sharex=True)
ax[0].plot(t, pv, label='PV availability')
ax[0].axhline(pcap, linestyle='--', label='Export cap')
ax[0].set_ylabel('Power (MW)')
ax[0].legend(loc='upper right', ncol=2)
ax[0].grid(alpha=0.25)

ax[1].plot(t, p2, linestyle='--', label='B2 corrected replay')
ax[1].plot(t, p3, label='B3 re-optimized')
ax[1].axhline(0, linewidth=0.8)
ax[1].set_ylabel('BESS power\n(MW)')
ax[1].legend(loc='upper right', ncol=2)
ax[1].grid(alpha=0.25)

ax[2].plot(t, soc2, linestyle='--', label='B2 corrected replay')
ax[2].plot(t, soc3, label='B3 re-optimized')
ax[2].set_ylabel('SOC (p.u.)')
ax[2].set_ylim(0.08, 0.92)
ax[2].legend(loc='upper right', ncol=2)
ax[2].grid(alpha=0.25)

ax[3].plot(t, amb, label='Ambient')
ax[3].plot(t, T2, linestyle='--', label='B2 cell')
ax[3].plot(t, T3, label='B3 cell')
ax[3].axhline(45.0, linestyle=':', label='Identification limit')
ax[3].set_ylabel('Temperature (°C)')
ax[3].legend(loc='upper right', ncol=4, fontsize=8)
ax[3].grid(alpha=0.25)
ax[3].set_xlim(pd.Timestamp('2023-07-20 00:00:00'), pd.Timestamp('2023-07-21 00:00:00'))
ax[3].xaxis.set_major_locator(mdates.HourLocator(byhour=range(0,25,3)))
ax[3].xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H'))
ax[3].set_xlabel('Time on 20 July 2023')
fig.tight_layout()
fig.savefig(OUT/'Figure_4.png', dpi=300, bbox_inches='tight')
plt.close(fig)

support4 = pd.DataFrame({
    'timestamp': sel['timestamp'].astype(str), 'pv_ac_mw': pv, 'ambient_C': amb,
    'B2_power_MW': p2, 'B3_power_MW': p3, 'B2_SOC': soc2, 'B3_SOC': soc3,
    'B2_cell_T_C': T2, 'B3_cell_T_C': T3,
})
support4.to_csv(OUT/'Figure_4_support.csv', index=False)

# ---------------- Figure 5: pathway decomposition + ablation ----------------
central = pd.read_csv(ROOT/'canonical_outputs/central_results.csv').iloc[0]
ab = pd.read_csv(ROOT/'canonical_outputs/pathway_property_ablation.csv')
base = central['B3_fixed25_MWh']
patha = central['B3_pathA_MWh']
full = central['B3_MWh']

fig, ax = plt.subplots(1, 2, figsize=(11.0, 3.15), gridspec_kw={'width_ratios':[1.0, 1.35]})
labels = ['Fixed properties\nat 25 °C', 'Path A only', 'Full electrothermal']
vals = np.array([base, patha, full]) / 1000.0
bars = ax[0].bar(labels, vals)
ax[0].set_ylabel('Annual curtailment (GWh)')
ax[0].set_title('(a) Pathway decomposition')
ax[0].set_ylim(8.62, 9.00)
for b,v in zip(bars, vals):
    ax[0].text(b.get_x()+b.get_width()/2, v+0.006, f'{v:.3f}', ha='center', va='bottom', fontsize=9)
ax[0].text(0.02, 0.96, 'Path A: +265.6 MWh/year', transform=ax[0].transAxes,
           ha='left', va='top', fontsize=8.2)

order = ['Q_only','R_only','OCV_only','feasibility_only','all_pathA']
lab2 = ['Q(T)','R(T)','OCV(T)','Feasibility','All Path A']
vals2 = [float(ab.loc[ab.config==k,'delta_vs_fixed25_MWh'].iloc[0]) for k in order]
bars2 = ax[1].barh(lab2, vals2)
ax[1].invert_yaxis()
ax[1].axvline(0, linewidth=0.8)
ax[1].set_xlabel('Change vs fixed-25 °C properties (MWh/year)')
ax[1].set_title('(b) Property-level Path-A ablation')
ax[1].set_xlim(-25, 290)
for b,v in zip(bars2, vals2):
    if v >= 0:
        x=v+2; ha='left'
    else:
        x=v-2; ha='right'
    ax[1].text(x, b.get_y()+b.get_height()/2, f'{v:+.1f}', va='center', ha=ha, fontsize=8.5)
fig.tight_layout()
fig.savefig(OUT/'Figure_5.png', dpi=300, bbox_inches='tight')
plt.close(fig)

# ---------------- Figure 6: final regime map ----------------
m = pd.read_csv(ROOT/'canonical_outputs/regime_map.csv')
temps = sorted(m['ambient_C'].unique())
pe = sorted(m['P_over_E_per_h'].unique())
rise = m.pivot(index='ambient_C', columns='P_over_E_per_h', values='self_heating_deltaTmax_C').loc[temps,pe]
util = m.pivot(index='ambient_C', columns='P_over_E_per_h', values='max_charge_current_util_pct').loc[temps,pe]
clips = m.pivot(index='ambient_C', columns='P_over_E_per_h', values='full_charge_clip_intervals').loc[temps,pe]

fig, ax = plt.subplots(1, 2, figsize=(10.2, 4.0))
im0 = ax[0].imshow(rise.values, origin='lower', aspect='auto')
im1 = ax[1].imshow(util.values, origin='lower', aspect='auto')
fig.colorbar(im0, ax=ax[0], label='Maximum self-heating rise (°C)')
fig.colorbar(im1, ax=ax[1], label='Charge-current utilization (%)')
for j,T in enumerate(temps):
    for i,p in enumerate(pe):
        ax[0].text(i, j, f'{rise.loc[T,p]:.2f}', ha='center', va='center', fontsize=7)
        txt = f'{util.loc[T,p]:.0f}'
        if clips.loc[T,p] > 0:
            txt += ' ×'
        ax[1].text(i, j, txt, ha='center', va='center', fontsize=7)
for a,title in zip(ax,['(a) Thermal amplification','(b) Charge-current utilization']):
    a.set_xticks(range(len(pe)), [f'{v:.3g}' for v in pe])
    a.set_yticks(range(len(temps)), [f'{v:g}' for v in temps])
    a.set_xlabel('BESS power-to-energy ratio, P/E (h⁻¹)')
    a.set_ylabel('Controlled ambient temperature (°C)')
    a.set_title(title)
ax[1].text(0.99, -0.20, '×  at least one B1-requested charge interval clipped in physical replay',
           transform=ax[1].transAxes, ha='right', va='top', fontsize=7.5)
fig.tight_layout()
fig.savefig(OUT/'Figure_6.png', dpi=300, bbox_inches='tight')
plt.close(fig)

# Summary for traceability
summary = {
    'Figure4_date':'2023-07-20',
    'Figure4_B2_curt_MWh': float(res['b2'].sum()*0.25),
    'Figure4_B3_curt_MWh': float(res['b3'].sum()*0.25),
    'Figure4_B2_terminal_SOC': float(rr2['soc'][-1]),
    'Figure4_B3_terminal_SOC': float(rr3['soc'][-1]),
    'Figure4_B2_maxT_C': float(T2.max()),
    'Figure4_B3_maxT_C': float(T3.max()),
    'Figure5_fixed25_GWh': float(base/1000),
    'Figure5_pathA_GWh': float(patha/1000),
    'Figure5_full_GWh': float(full/1000),
    'Figure6_clipped_combinations': int((clips.values>0).sum()),
    'Figure6_max_deltaT_C': float(rise.values.max()),
    'Figure6_max_util_pct': float(util.values.max()),
}
import json
(OUT/'FIGURE_TRACEABILITY.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
