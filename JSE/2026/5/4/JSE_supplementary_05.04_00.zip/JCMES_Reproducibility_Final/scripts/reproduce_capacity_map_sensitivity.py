from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))

import json,time
import numpy as np,pandas as pd
from scipy.interpolate import PchipInterpolator
from multiprocessing import Pool
import electrothermal_model as m
D=pd.read_csv(ROOT/'processed_inputs'/'recon_pv15.csv');PV=D.pv_ac_mw.to_numpy(float);AMB=D.ambient_C.to_numpy(float);DT=.25
capdf=pd.read_csv(ROOT/'battery_model'/'capacity_vs_temperature.csv');T=capdf.temperature_C.to_numpy(float);mean=capdf.capacity_Ah.to_numpy(float);ch=capdf.charge_Ah.to_numpy(float);dis=capdf.discharge_Ah.to_numpy(float);q25=m.QREF25
maps={'charge':ch*(q25/np.interp(25,T,ch)),'discharge':dis*(q25/np.interp(25,T,dis)),'mean_linear':mean.copy()}
VAR=None

def set_variant(v):
    if v=='pchip':
      local=PchipInterpolator(T,mean,extrapolate=False);m.cap=lambda temp: float(local(float(np.clip(temp,T[0],T[-1]))));return
    m.capQ=maps[v].copy();m.cap=lambda temp: float(np.interp(np.clip(temp,m.capT[0],m.capT[-1]),m.capT,m.capQ))

def worker(d):
    set_variant(VAR);sl=slice(d*96,(d+1)*96);r=m.solve_day(PV[sl],AMB[sl],DT,.85,30.,140.,m.CONFIGS['all_pathA']);return d,float(r['b3'].sum()*DT)
if __name__=='__main__':
    out=ROOT/'reproduced_outputs';out.mkdir(exist_ok=True);fixed=json.load(open(ROOT/'canonical_outputs'/'central_results.json'))['B3_fixed25_MWh'];summary={}
    for v in ['charge','discharge','pchip']:
      VAR=v;t=time.time()
      with Pool(6) as p: rows=p.map(worker,range(365),chunksize=3)
      df=pd.DataFrame(rows,columns=['day','B3_MWh']).sort_values('day');df.to_csv(out/f'capacity_map_{v}_daily.csv',index=False);b=float(df.B3_MWh.sum());summary[v]={'B3_MWh':b,'PathA_MWh':b-fixed,'runtime_s':time.time()-t}
    (out/'capacity_map_sensitivity.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
