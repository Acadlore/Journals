# Held-out validation data source

The two MAT files are from:
A. K. de Souza, “Lithium-ion Battery OCV and Dynamic Test Data of a LiFePO4 cylindrical cell,” Mendeley Data, Version 1, 2021, DOI: 10.17632/p8kf893yv3.1.

The Mendeley Data record lists the dataset under the Creative Commons Attribution 4.0 (CC BY 4.0) licence. These two UDDS files are the held-out 25 °C and 35 °C profiles used for the validation reported in the manuscript.
