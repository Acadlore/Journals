from pathlib import Path
import shutil,subprocess,sys,os
root=Path(__file__).resolve().parent
os.chdir(root)
(root/'research').mkdir(exist_ok=True)
shutil.copyfile(root/'data/air_observations.csv',root/'research/air_observations.csv')
subprocess.run([sys.executable,'research/analyze.py'],check=True)
subprocess.run([sys.executable,'research/monthly_models.py'],check=True)
print('Numerical results and figures are in output/')
